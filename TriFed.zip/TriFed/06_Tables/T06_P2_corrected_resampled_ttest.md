# Table P2-3. Corrected resampled t-test (Nadeau–Bengio), CIR-CalBoost minus each existing method

| Baseline     | Metric     |   Delta |      p |   SeedWins |   p_Holm |
|:-------------|:-----------|--------:|-------:|-----------:|---------:|
| BalancedRF   | Accuracy   | -0.0034 | 0.8207 |          3 |   1      |
| BalancedRF   | BAcc       |  0.0073 | 0.6077 |          3 |   1      |
| BalancedRF   | F1         |  0.01   | 0.5464 |          3 |   1      |
| BalancedRF   | MCC        |  0.01   | 0.7086 |          3 |   1      |
| BalancedRF   | ROC-AUC    |  0.0046 | 0.3569 |          5 |   0.7789 |
| BalancedRF   | PR-AUC     |  0.0071 | 0.5967 |          4 |   1      |
| BalancedRF   | Brier ↓    | -0.0057 | 0.029  |          5 |   0.0579 |
| BalancedRF   | ECE ↓      | -0.0072 | 0.5914 |          3 |   0.5914 |
| BalancedRF   | Log loss ↓ | -0.0157 | 0.0184 |          5 |   0.0368 |
| EasyEnsemble | Accuracy   |  0.002  | 0.9131 |          3 |   1      |
| EasyEnsemble | BAcc       |  0.0069 | 0.7289 |          3 |   1      |
| EasyEnsemble | F1         |  0.0098 | 0.6669 |          3 |   1      |
| EasyEnsemble | MCC        |  0.0129 | 0.7315 |          3 |   1      |
| EasyEnsemble | ROC-AUC    |  0.0075 | 0.2658 |          5 |   0.7789 |
| EasyEnsemble | PR-AUC     |  0.0084 | 0.495  |          5 |   1      |
| EasyEnsemble | Brier ↓    | -0.0422 | 0      |          5 |   0      |
| EasyEnsemble | ECE ↓      | -0.1013 | 0.0001 |          5 |   0.0003 |
| EasyEnsemble | Log loss ↓ | -0.1127 | 0      |          5 |   0      |
| RUSBoost     | Accuracy   |  0.0214 | 0.2497 |          5 |   1      |
| RUSBoost     | BAcc       |  0.0443 | 0.0223 |          5 |   0.1114 |
| RUSBoost     | F1         |  0.0561 | 0.0167 |          5 |   0.0833 |
| RUSBoost     | MCC        |  0.0758 | 0.0398 |          5 |   0.1988 |
| RUSBoost     | ROC-AUC    |  0.0292 | 0.0128 |          5 |   0.0639 |
| RUSBoost     | PR-AUC     |  0.042  | 0.0252 |          5 |   0.1258 |
| RUSBoost     | Brier ↓    | -0.0235 | 0.0013 |          5 |   0.0039 |
| RUSBoost     | ECE ↓      | -0.0386 | 0.0109 |          5 |   0.0326 |
| RUSBoost     | Log loss ↓ | -0.066  | 0.0006 |          5 |   0.0019 |
| WeightedXGB  | Accuracy   |  0.0007 | 0.9644 |          3 |   1      |
| WeightedXGB  | BAcc       |  0.0116 | 0.485  |          4 |   1      |
| WeightedXGB  | F1         |  0.0155 | 0.4244 |          5 |   1      |
| WeightedXGB  | MCC        |  0.0189 | 0.5448 |          3 |   1      |
| WeightedXGB  | ROC-AUC    |  0.0067 | 0.2596 |          5 |   0.7789 |
| WeightedXGB  | PR-AUC     |  0.007  | 0.5349 |          3 |   1      |
| WeightedXGB  | Brier ↓    | -0.0088 | 0.0426 |          5 |   0.0579 |
| WeightedXGB  | ECE ↓      | -0.0176 | 0.12   |          5 |   0.24   |
| WeightedXGB  | Log loss ↓ | -0.0279 | 0.0217 |          5 |   0.0368 |
| SMOTEENN-XGB | Accuracy   |  0.0172 | 0.3044 |          4 |   1      |
| SMOTEENN-XGB | BAcc       |  0.0073 | 0.6516 |          4 |   1      |
| SMOTEENN-XGB | F1         |  0.0083 | 0.6306 |          3 |   1      |
| SMOTEENN-XGB | MCC        |  0.0183 | 0.5601 |          4 |   1      |
| SMOTEENN-XGB | ROC-AUC    |  0.0108 | 0.0991 |          5 |   0.3964 |
| SMOTEENN-XGB | PR-AUC     |  0.0229 | 0.0985 |          5 |   0.3939 |
| SMOTEENN-XGB | Brier ↓    | -0.0492 | 0.0001 |          5 |   0.0003 |
| SMOTEENN-XGB | ECE ↓      | -0.1036 | 0      |          5 |   0      |
| SMOTEENN-XGB | Log loss ↓ | -0.276  | 0      |          5 |   0.0001 |

J = 25 trials, test/train ratio 1/4, df = 24; Holm correction across the five existing methods per metric. SeedWins = seeds (of 5) in which CIR-CalBoost was better.
