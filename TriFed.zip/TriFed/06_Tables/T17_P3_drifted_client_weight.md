# Table P3-8. Aggregation weight of the drifted client before and after drift (mean over seeds)

| Scenario   | Method   |   Weight rounds 21–25 |   Weight rounds 26–30 |   Weight rounds 46–50 |
|:-----------|:---------|----------------------:|----------------------:|----------------------:|
| label      | FedAvg   |                 0.435 |                 0.435 |                 0.435 |
| label      | QPW-Fed  |                 0.248 |                 0.247 |                 0.249 |
| label      | Uniform  |                 0.2   |                 0.2   |                 0.2   |
| sensor     | FedAvg   |                 0.435 |                 0.435 |                 0.435 |
| sensor     | QPW-Fed  |                 0.248 |                 0.229 |                 0.233 |
| sensor     | Uniform  |                 0.2   |                 0.2   |                 0.2   |
