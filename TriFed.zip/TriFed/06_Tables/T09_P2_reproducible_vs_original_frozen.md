# Table P2-6. Reproducible re-implementation (reported) vs original frozen run

| Method       | Metric   |   Reproducible (reported) |   Original frozen run |   Difference |
|:-------------|:---------|--------------------------:|----------------------:|-------------:|
| CIR-CalBoost | MCC      |                    0.5058 |                0.5165 |      -0.0107 |
| CIR-CalBoost | ROC-AUC  |                    0.8396 |                0.8425 |      -0.003  |
| CIR-CalBoost | Brier ↓  |                    0.1566 |                0.1558 |       0.0008 |
| CIR-CalBoost | ECE ↓    |                    0.0837 |                0.0882 |      -0.0045 |
| BalancedRF   | MCC      |                    0.4958 |                0.4906 |       0.0052 |
| BalancedRF   | ROC-AUC  |                    0.835  |                0.8343 |       0.0006 |
| BalancedRF   | Brier ↓  |                    0.1623 |                0.1624 |      -0.0001 |
| BalancedRF   | ECE ↓    |                    0.091  |                0.0919 |      -0.0009 |
| EasyEnsemble | MCC      |                    0.493  |                0.5025 |      -0.0095 |
| EasyEnsemble | ROC-AUC  |                    0.8321 |                0.8324 |      -0.0003 |
| EasyEnsemble | Brier ↓  |                    0.1988 |                0.1985 |       0.0003 |
| EasyEnsemble | ECE ↓    |                    0.185  |                0.1855 |      -0.0005 |
| RUSBoost     | MCC      |                    0.43   |                0.4188 |       0.0112 |
| RUSBoost     | ROC-AUC  |                    0.8104 |                0.807  |       0.0033 |
| RUSBoost     | Brier ↓  |                    0.1801 |                0.1815 |      -0.0014 |
| RUSBoost     | ECE ↓    |                    0.1223 |                0.123  |      -0.0007 |
| WeightedXGB  | MCC      |                    0.4869 |                0.4839 |       0.003  |
| WeightedXGB  | ROC-AUC  |                    0.8328 |                0.8315 |       0.0013 |
| WeightedXGB  | Brier ↓  |                    0.1654 |                0.1613 |       0.0041 |
| WeightedXGB  | ECE ↓    |                    0.1013 |                0.0951 |       0.0061 |
| SMOTEENN-XGB | MCC      |                    0.4875 |                0.5017 |      -0.0142 |
| SMOTEENN-XGB | ROC-AUC  |                    0.8287 |                0.8289 |      -0.0002 |
| SMOTEENN-XGB | Brier ↓  |                    0.2059 |                0.2004 |       0.0055 |
| SMOTEENN-XGB | ECE ↓    |                    0.1874 |                0.1811 |       0.0063 |

The original centralized code could not be located; reported numbers come from notebooks R1/R2.
