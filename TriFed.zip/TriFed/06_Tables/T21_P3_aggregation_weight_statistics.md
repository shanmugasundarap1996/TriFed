# Table P3-12. How each method distributes client influence (10 seeds × 50 rounds)

| Method   |   Mean per-round max weight |   Mean per-round min weight |   Normalized weight entropy |   Correlation with sample share |
|:---------|----------------------------:|----------------------------:|----------------------------:|--------------------------------:|
| FedAdam  |                       0.435 |                       0.055 |                       0.847 |                           1     |
| FedAvg   |                       0.435 |                       0.055 |                       0.847 |                           1     |
| FedProx  |                       0.435 |                       0.055 |                       0.847 |                           1     |
| QPW-Fed  |                       0.254 |                       0.15  |                       0.989 |                           0.853 |

Uniform weighting would give max = min = 0.20 and entropy 1.0.
