# Table P1-3. Strongest existing method for each metric

| Metric      | Best existing method   |   Mean |
|:------------|:-----------------------|-------:|
| Accuracy    | BalancedRF             | 0.7586 |
| BAcc        | EasyEnsemble           | 0.755  |
| F1          | SMOTEENN-XGB           | 0.6828 |
| MCC         | BalancedRF             | 0.4958 |
| ROC-AUC     | BalancedRF             | 0.835  |
| PR-AUC      | WeightedXGB            | 0.7168 |
| Brier ↓     | BalancedRF             | 0.1623 |
| ECE ↓       | BalancedRF             | 0.091  |
| Log loss ↓  | BalancedRF             | 0.49   |
| Sensitivity | SMOTEENN-XGB           | 0.8091 |
| Specificity | RUSBoost               | 0.7716 |
| Precision   | BalancedRF             | 0.6342 |
