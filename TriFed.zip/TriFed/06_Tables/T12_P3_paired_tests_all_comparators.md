# Table P3-3. Paired Wilcoxon tests, QPW-Fed minus each comparator (10 seeds; uncorrected, exploratory)

| Comparator   | Metric      |   Mean Δ (QPW-Fed − comparator) |   Seeds favouring QPW-Fed |   Wilcoxon p |
|:-------------|:------------|--------------------------------:|--------------------------:|-------------:|
| FedAvg       | Accuracy    |                         -0.0169 |                         1 |       0.0156 |
| FedAvg       | BAcc        |                          0.0074 |                         7 |       0.1309 |
| FedAvg       | Sensitivity |                          0.0889 |                        10 |       0.002  |
| FedAvg       | Specificity |                         -0.074  |                         0 |       0.0039 |
| FedAvg       | F1          |                          0.0121 |                         7 |       0.1309 |
| FedAvg       | MCC         |                         -0.0001 |                         7 |       0.6953 |
| FedAvg       | ROC-AUC     |                          0.004  |                         6 |       0.3223 |
| FedAvg       | PR-AUC      |                          0.0119 |                         7 |       0.375  |
| FedAvg       | Brier ↓     |                         -0.0037 |                         7 |       0.084  |
| FedAvg       | ECE ↓       |                         -0.0124 |                         7 |       0.3223 |
| FedAvg       | Log loss ↓  |                         -0.0051 |                         7 |       0.1602 |
| FedProx      | Accuracy    |                         -0.0169 |                         1 |       0.0078 |
| FedProx      | BAcc        |                          0.0074 |                         6 |       0.2324 |
| FedProx      | Sensitivity |                          0.0889 |                        10 |       0.002  |
| FedProx      | Specificity |                         -0.074  |                         0 |       0.0039 |
| FedProx      | F1          |                          0.0123 |                         7 |       0.1934 |
| FedProx      | MCC         |                         -0.0001 |                         6 |       0.7695 |
| FedProx      | ROC-AUC     |                          0.0042 |                         6 |       0.2754 |
| FedProx      | PR-AUC      |                          0.0123 |                         7 |       0.3223 |
| FedProx      | Brier ↓     |                         -0.0037 |                         7 |       0.0488 |
| FedProx      | ECE ↓       |                         -0.0124 |                         7 |       0.3223 |
| FedProx      | Log loss ↓  |                         -0.0052 |                         7 |       0.1309 |
| FedAdam      | Accuracy    |                          0      |                         5 |       0.8555 |
| FedAdam      | BAcc        |                          0.0311 |                         7 |       0.084  |
| FedAdam      | Sensitivity |                          0.1352 |                         7 |       0.0918 |
| FedAdam      | Specificity |                         -0.073  |                         3 |       0.1602 |
| FedAdam      | F1          |                          0.0566 |                         7 |       0.084  |
| FedAdam      | MCC         |                          0.0348 |                         7 |       0.1055 |
| FedAdam      | ROC-AUC     |                          0.0136 |                         8 |       0.0273 |
| FedAdam      | PR-AUC      |                          0.0313 |                         8 |       0.0645 |
| FedAdam      | Brier ↓     |                         -0.0153 |                         8 |       0.0273 |
| FedAdam      | ECE ↓       |                         -0.0224 |                         7 |       0.375  |
| FedAdam      | Log loss ↓  |                         -0.0709 |                         8 |       0.0371 |
| Uniform      | Accuracy    |                          0.0097 |                         7 |       0.0273 |
| Uniform      | BAcc        |                          0.0028 |                         6 |       0.416  |
| Uniform      | Sensitivity |                         -0.0204 |                         1 |       0.125  |
| Uniform      | Specificity |                          0.026  |                         8 |       0.0234 |
| Uniform      | F1          |                          0.0017 |                         5 |       0.625  |
| Uniform      | MCC         |                          0.006  |                         6 |       0.4316 |
| Uniform      | ROC-AUC     |                          0.0004 |                         5 |       0.7695 |
| Uniform      | PR-AUC      |                          0.0011 |                         5 |       0.6953 |
| Uniform      | Brier ↓     |                         -0.0038 |                         8 |       0.0371 |
| Uniform      | ECE ↓       |                         -0.0144 |                         7 |       0.084  |
| Uniform      | Log loss ↓  |                         -0.0111 |                         9 |       0.0098 |
