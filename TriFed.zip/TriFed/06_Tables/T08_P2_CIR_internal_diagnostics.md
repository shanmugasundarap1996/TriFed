# Table P2-5. What CIR-CalBoost learned inside the training folds

| Item                                  | Value                        |
|:--------------------------------------|:-----------------------------|
| Ensemble weight XGBoost (mean ± SD)   | 0.058 ± 0.091                |
| Ensemble weight Random forest         | 0.674 ± 0.085                |
| Ensemble weight Logistic regression   | 0.268 ± 0.077                |
| Calibration chosen                    | none: 16, sigmoid: 9         |
| Interaction term dropped by screening | BMI_sq: 22, Glucose_x_DPF: 3 |
| Decision threshold (mean ± SD; range) | 0.394 ± 0.043; 0.33–0.47     |
