# Table P3-6. Client drift: Round-50 performance (largest client corrupted from round 26; 10 seeds)

| Scenario                     | Method   |    MCC |   ROC-AUC |   PR-AUC |   Brier ↓ |   BAcc |   ΔROC-AUC vs stationary |   ΔMCC vs stationary |
|:-----------------------------|:---------|-------:|----------:|---------:|----------:|-------:|-------------------------:|---------------------:|
| Label noise (40% flips)      | FedAvg   | 0.4389 |    0.8267 |   0.6985 |    0.1922 | 0.7186 |                  -0.0173 |              -0.0665 |
| Label noise (40% flips)      | Uniform  | 0.4728 |    0.8412 |   0.718  |    0.1773 | 0.7427 |                  -0.0063 |              -0.0267 |
| Label noise (40% flips)      | QPW-Fed  | 0.4819 |    0.8403 |   0.7171 |    0.178  | 0.7474 |                  -0.0076 |              -0.0234 |
| Sensor failure (60% missing) | FedAvg   | 0.4744 |    0.8424 |   0.7257 |    0.162  | 0.7412 |                  -0.0015 |              -0.031  |
| Sensor failure (60% missing) | Uniform  | 0.4941 |    0.8461 |   0.7287 |    0.1611 | 0.7563 |                  -0.0014 |              -0.0053 |
| Sensor failure (60% missing) | QPW-Fed  | 0.4891 |    0.8469 |   0.7298 |    0.1582 | 0.7533 |                  -0.0011 |              -0.0162 |
