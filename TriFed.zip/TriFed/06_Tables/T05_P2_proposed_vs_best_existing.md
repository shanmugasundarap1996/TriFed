# Table P2-2. CIR-CalBoost versus the strongest existing method for each metric

| Metric     | Best existing   |   Existing |   CIR-CalBoost |   Δ (proposed − existing) | Proposed better?   |
|:-----------|:----------------|-----------:|---------------:|--------------------------:|:-------------------|
| Accuracy   | BalancedRF      |     0.7586 |         0.7552 |                   -0.0034 | no                 |
| BAcc       | EasyEnsemble    |     0.755  |         0.7619 |                    0.0069 | yes                |
| F1         | SMOTEENN-XGB    |     0.6828 |         0.6911 |                    0.0083 | yes                |
| MCC        | BalancedRF      |     0.4958 |         0.5058 |                    0.01   | yes                |
| ROC-AUC    | BalancedRF      |     0.835  |         0.8396 |                    0.0046 | yes                |
| PR-AUC     | WeightedXGB     |     0.7168 |         0.7239 |                    0.007  | yes                |
| Brier ↓    | BalancedRF      |     0.1623 |         0.1566 |                   -0.0057 | yes                |
| ECE ↓      | BalancedRF      |     0.091  |         0.0837 |                   -0.0072 | yes                |
| Log loss ↓ | BalancedRF      |     0.49   |         0.4743 |                   -0.0157 | yes                |
