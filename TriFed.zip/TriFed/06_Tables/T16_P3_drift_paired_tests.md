# Table P3-7. Client drift: paired tests at Round 50, QPW-Fed minus comparator (exploratory)

| Scenario       | Comparator   | Metric   |   Mean Δ (QPW-Fed − comparator) |   Seeds favouring QPW-Fed |   Wilcoxon p |
|:---------------|:-------------|:---------|--------------------------------:|--------------------------:|-------------:|
| Label noise    | FedAvg       | MCC      |                          0.043  |                         7 |       0.1309 |
| Label noise    | FedAvg       | ROC-AUC  |                          0.0136 |                         9 |       0.0039 |
| Label noise    | FedAvg       | PR-AUC   |                          0.0185 |                        10 |       0.002  |
| Label noise    | FedAvg       | Brier ↓  |                         -0.0142 |                         9 |       0.0039 |
| Label noise    | Uniform      | MCC      |                          0.0092 |                         4 |       0.2188 |
| Label noise    | Uniform      | ROC-AUC  |                         -0.0009 |                         2 |       0.1855 |
| Label noise    | Uniform      | PR-AUC   |                         -0.0009 |                         3 |       0.375  |
| Label noise    | Uniform      | Brier ↓  |                          0.0007 |                         3 |       0.375  |
| Sensor failure | FedAvg       | MCC      |                          0.0147 |                         6 |       0.1602 |
| Sensor failure | FedAvg       | ROC-AUC  |                          0.0045 |                         7 |       0.2324 |
| Sensor failure | FedAvg       | PR-AUC   |                          0.0041 |                         5 |       1      |
| Sensor failure | FedAvg       | Brier ↓  |                         -0.0038 |                         7 |       0.0488 |
| Sensor failure | Uniform      | MCC      |                         -0.005  |                         3 |       0.5566 |
| Sensor failure | Uniform      | ROC-AUC  |                          0.0008 |                         6 |       0.3848 |
| Sensor failure | Uniform      | PR-AUC   |                          0.001  |                         6 |       0.625  |
| Sensor failure | Uniform      | Brier ↓  |                         -0.0029 |                         7 |       0.0645 |
