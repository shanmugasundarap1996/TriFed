# Table P3-14. Wall-clock seconds per 50-round federated run (single CPU core, AMD Ryzen 5 5625U)

| Method   |   mean |   std |
|:---------|-------:|------:|
| FedAdam  |   14.7 |   0.3 |
| FedAvg   |   15.9 |   1.7 |
| FedProx  |   16.3 |   1   |
| QPW-Fed  |   14.9 |   0.4 |
| Uniform  |   14.7 |   0.4 |
