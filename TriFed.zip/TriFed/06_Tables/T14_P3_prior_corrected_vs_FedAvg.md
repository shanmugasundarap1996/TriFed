# Table P3-5. Prior-corrected QPW-Fed vs FedAvg (10 evaluation seeds)

| Metric      |   Mean Δ (QPW-Fed-PC − FedAvg) |   Seeds favouring QPW-Fed-PC |   Wilcoxon p |
|:------------|-------------------------------:|-----------------------------:|-------------:|
| |Intercept| |                        -0.0906 |                            7 |       0.0371 |
| Brier       |                        -0.0063 |                            7 |       0.0488 |
| ECE         |                        -0.0209 |                            9 |       0.0273 |
| Log loss    |                        -0.0128 |                            7 |       0.0645 |
