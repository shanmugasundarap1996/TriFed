# Table P2-4. Holm-adjusted p-values (rows: metric; columns: existing method)

| Metric     |   BalancedRF |   EasyEnsemble |   RUSBoost |   SMOTEENN-XGB |   WeightedXGB |
|:-----------|-------------:|---------------:|-----------:|---------------:|--------------:|
| Accuracy   |        1     |          1     |      1     |          1     |         1     |
| BAcc       |        1     |          1     |      0.111 |          1     |         1     |
| Brier ↓    |        0.058 |          0     |      0.004 |          0     |         0.058 |
| ECE ↓      |        0.591 |          0     |      0.033 |          0     |         0.24  |
| F1         |        1     |          1     |      0.083 |          1     |         1     |
| Log loss ↓ |        0.037 |          0     |      0.002 |          0     |         0.037 |
| MCC        |        1     |          1     |      0.199 |          1     |         1     |
| PR-AUC     |        1     |          1     |      0.126 |          0.394 |         1     |
| ROC-AUC    |        0.779 |          0.779 |      0.064 |          0.396 |         0.779 |
