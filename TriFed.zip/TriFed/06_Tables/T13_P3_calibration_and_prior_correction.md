# Table P3-4. Calibration of federated models (means over 10 seeds) and the prevalence-aware correction

| Method                                 |   EffPrev |   MeanPred |   Intercept |    Slope |    O/E |   Brier |    ECE |   LogLoss |
|:---------------------------------------|----------:|-----------:|------------:|---------:|-------:|--------:|-------:|----------:|
| FedAvg                                 |    0.3486 |     0.3473 |      0.0042 |   1.4188 | 1.0312 |  0.1604 | 0.0999 |    0.4799 |
| FedProx                                |    0.3486 |     0.3472 |      0.0043 |   1.4181 | 1.0314 |  0.1604 | 0.1    |    0.4801 |
| FedAdam                                |    0.3486 |     0.3228 |      0.3374 |   0.7947 | 1.2727 |  0.172  | 0.1099 |    0.5457 |
| Uniform                                |    0.4143 |     0.4194 |     -0.3937 |   1.3392 | 0.847  |  0.1605 | 0.1019 |    0.486  |
| QPW-Fed                                |    0.3917 |     0.4003 |     -0.2866 |   1.3077 | 0.8844 |  0.1567 | 0.0876 |    0.4749 |
| QPW-Fed-PC (proposed, prior-corrected) |  nan      |   nan      |     -0.1067 | nan      | 0.9587 |  0.154  | 0.0791 |    0.4672 |

Ideal: Intercept 0, Slope 1, O/E 1. Observed test prevalence 0.351. EffPrev = aggregation-weighted client prevalence. QPW-Fed-PC changes probabilities only; ROC-AUC and labels are unchanged.
