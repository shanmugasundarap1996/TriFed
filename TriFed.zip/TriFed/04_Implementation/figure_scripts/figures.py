import glob, os
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

P = r"D:\diabetic project"
FIN = P + r"\PHASE3_QPW_FED\PHASE3_FINAL_ALL_METHODS_QPWFED_V3"
ABL = P + r"\PHASE3_QPW_FED\PHASE3_ABLATION_EXACT_FROZEN_SOURCE\results"
CIR = P + r"\FROZEN_FINAL_CIR_CALBOOST_V2"
OUT = P + r"\paper writing\figures"
os.makedirs(OUT, exist_ok=True)

# Reference categorical palette, fixed order (dataviz skill, light mode).
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300"]
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
plt.rcParams.update({
    "font.family": "serif", "font.size": 8, "axes.edgecolor": INK2, "axes.labelcolor": INK,
    "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.5, "axes.axisbelow": True,
    "legend.frameon": False, "savefig.dpi": 600, "savefig.bbox": "tight", "figure.facecolor": "white",
})

def grouped(ax, df, methods, metrics, labels, title, ylim=None):
    n = len(methods); width = 0.8 / n; x = np.arange(len(metrics))
    for i, m in enumerate(methods):
        g = df[df.Method == m]
        ax.bar(x + (i - (n - 1) / 2) * width, [g[c].mean() for c in metrics], width * 0.9,
               yerr=[g[c].std(ddof=1) for c in metrics], color=SERIES[i], label=m,
               error_kw=dict(elinewidth=0.6, capsize=1.5, ecolor=INK2), edgecolor="white", linewidth=0.6)
    ax.set_xticks(x, labels); ax.set_title(title, color=INK, fontsize=8.5, loc="left")
    if ylim: ax.set_ylim(*ylim)
    ax.grid(axis="x", visible=False)

# ---------- Fig: centralized (frozen run) ----------
c = pd.read_csv(CIR + r"\FROZEN_AllMethods_25Trials.csv")
c["Method"] = c["Method"].replace({"CIR-CalBoost V2": "CIR-CalBoost", "SMOTEENN_XGB": "SMOTEENN-XGB"})
cm = ["BalancedRF", "EasyEnsemble", "RUSBoost", "WeightedXGB", "SMOTEENN-XGB", "CIR-CalBoost"]
fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.6), gridspec_kw={"width_ratios": [2, 1]})
grouped(axs[0], c, cm, ["Accuracy", "Balanced_Accuracy", "F1", "MCC", "ROC_AUC", "PR_AUC"],
        ["Acc", "BAcc", "F1", "MCC", "ROC-AUC", "PR-AUC"], "(a) Classification and discrimination (higher is better)", (0.3, 0.92))
grouped(axs[1], c, cm, ["Brier", "ECE", "LogLoss"], ["Brier", "ECE", "Log loss"], "(b) Probability quality (lower is better)")
axs[0].legend(ncol=6, loc="upper left", bbox_to_anchor=(0, -0.12), fontsize=7)
fig.savefig(OUT + r"\fig_centralized.png"); plt.close(fig)

# ---------- Fig: federated round 50 ----------
f = pd.read_csv(FIN + r"\results\FinalRound50_PerSeed.csv")
f["Method"] = f["Method"].replace({"QPW-Fed-V3": "QPW-Fed"})
fm = ["FedAvg", "FedProx", "FedAdam", "QPW-Fed"]
fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.6), gridspec_kw={"width_ratios": [2, 1]})
grouped(axs[0], f, fm, ["Accuracy", "Balanced_Accuracy", "F1", "MCC", "ROC_AUC", "PR_AUC"],
        ["Acc", "BAcc", "F1", "MCC", "ROC-AUC", "PR-AUC"], "(a) Classification and discrimination (higher is better)", (0.3, 0.92))
grouped(axs[1], f, fm, ["Brier", "ECE", "LogLoss"], ["Brier", "ECE", "Log loss"], "(b) Probability quality (lower is better)")
axs[0].legend(ncol=4, loc="upper left", bbox_to_anchor=(0, -0.12), fontsize=7)
fig.savefig(OUT + r"\fig_federated.png"); plt.close(fig)

# ---------- Fig: convergence ----------
r = pd.read_csv(FIN + r"\results\AllRounds_AllMethods.csv")
r["Method"] = r["Method"].replace({"QPW-Fed-V3": "QPW-Fed"})
fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.4), gridspec_kw={"wspace": 0.3})
for ax, met, lab in [(axs[0], "MCC", "MCC"), (axs[1], "Balanced_Accuracy", "Balanced accuracy")]:
    for i, m in enumerate(fm):
        g = r[r.Method == m].groupby("Round")[met].agg(["mean", "std"])
        ax.plot(g.index, g["mean"], color=SERIES[i], lw=1.4, label=m)
        ax.fill_between(g.index, g["mean"] - g["std"], g["mean"] + g["std"], color=SERIES[i], alpha=0.10, lw=0)
    ax.set_xlabel("Communication round"); ax.set_ylabel(f"Global-test {lab}"); ax.set_xlim(1, 50)
    ax.axvline(50, color=INK2, lw=0.6, ls=":")
axs[0].legend(ncol=4, loc="upper left", bbox_to_anchor=(0, -0.2), fontsize=7)
fig.savefig(OUT + r"\fig_convergence.png"); plt.close(fig)

# ---------- Fig: client heterogeneity (sizes + positive share) ----------
rows = []
for sd in sorted(glob.glob(FIN + r"\partitions\seed_*")):
    seed = int(sd.split("_")[-1])
    for k in range(1, 6):
        d = pd.read_csv(os.path.join(sd, f"client_{k}.csv"))
        rows.append(dict(Seed=seed, Client=k, N=len(d), Pos=d["Outcome"].mean()))
h = pd.DataFrame(rows)
sizes = h.pivot(index="Seed", columns="Client", values="N"); pos = h.pivot(index="Seed", columns="Client", values="Pos")
fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.0), gridspec_kw={"wspace": 0.45})
for ax, M, cmap, fmt, title in [(axs[0], sizes, "Blues", "{:.0f}", "(a) Client sample size"),
                                (axs[1], pos, "Blues", "{:.2f}", "(b) Positive-class proportion")]:
    im = ax.imshow(M.values, cmap=cmap, aspect="auto")
    vmax = np.nanmax(M.values)
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            v = M.values[i, j]
            ax.text(j, i, fmt.format(v), ha="center", va="center", fontsize=6.5,
                    color="white" if v > 0.6 * vmax else INK)
    ax.set_xticks(range(5), [f"C{k}" for k in range(1, 6)]); ax.set_yticks(range(len(M)), M.index)
    ax.set_title(title, loc="left", fontsize=8.5); ax.grid(False)
    fig.colorbar(im, ax=ax, fraction=0.04, pad=0.02)
axs[0].set_ylabel("Seed")
fig.savefig(OUT + r"\fig_client_heterogeneity.png"); plt.close(fig)
h.to_csv(OUT + r"\client_heterogeneity_source.csv", index=False)

# ---------- Fig: aggregation weights ----------
dfin = pd.read_csv(FIN + r"\results\ClientDiagnostics_AllMethods.csv")
dab = pd.read_csv(ABL + r"\ClientDiagnostics_AllMethods.csv")
data = [dfin[dfin.Method == "FedAvg"]["Weight"], dab[dab.Method == "A0_N"]["Weight"],
        dab[dab.Method == "A1_NP"]["Weight"], dab[dab.Method == "A4_FULL_NQPCRG"]["Weight"]]
labels = ["FedAvg\n(sample share)", "A0\n(N)", "A1\n(N+P)", "QPW-Fed\n(A4)"]
fig, ax = plt.subplots(figsize=(3.5, 2.6))
bp = ax.boxplot(data, widths=0.5, patch_artist=True, showfliers=False,
                medianprops=dict(color=INK, lw=1), whiskerprops=dict(color=INK2, lw=0.8), capprops=dict(color=INK2, lw=0.8))
for patch in bp["boxes"]:
    patch.set_facecolor("#9ec5f4"); patch.set_edgecolor(INK2); patch.set_linewidth(0.8)
ax.set_xticks(range(1, 5), labels)
ax.axhline(0.2, color=INK2, lw=0.8, ls="--"); ax.text(1.5, 0.205, "uniform 1/K", fontsize=6.0, color=INK2, ha="center", va="bottom")
ax.set_ylabel("Client aggregation weight per round"); ax.grid(axis="x", visible=False)
fig.savefig(OUT + r"\fig_client_weights.png"); plt.close(fig)

# ---------- Fig: ablation ----------
a = pd.read_csv(ABL + r"\FinalRound50_PerSeed.csv")
vs = ["A0_N", "A1_NP", "A2_NQPC", "A3_NQPCR", "A4_FULL_NQPCRG"]; vl = ["A0", "A1", "A2", "A3", "A4"]
mets = [("MCC", "MCC"), ("Balanced_Accuracy", "BAcc"), ("F1", "F1"), ("ROC_AUC", "ROC-AUC"), ("PR_AUC", "PR-AUC")]
fig, axs = plt.subplots(1, 5, figsize=(7.2, 1.9))
for ax, (met, lab) in zip(axs, mets):
    mu = [a[a.Method == v][met].mean() for v in vs]
    se = [a[a.Method == v][met].std(ddof=1) / np.sqrt(10) for v in vs]
    ax.errorbar(range(5), mu, yerr=se, color=SERIES[0], marker="o", ms=4, lw=1.2, capsize=1.5, elinewidth=0.6)
    ax.set_xticks(range(5), vl); ax.set_title(lab, fontsize=8.5, loc="left"); ax.grid(axis="x", visible=False)
    ax.tick_params(axis="y", labelsize=6.5)
fig.tight_layout(w_pad=0.6)
fig.savefig(OUT + r"\fig_ablation.png"); plt.close(fig)
print("written:", sorted(os.listdir(OUT)))
