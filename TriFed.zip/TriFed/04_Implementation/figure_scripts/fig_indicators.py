import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
OUT = r"D:\diabetic project\paper writing\figures"
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300"]; INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
plt.rcParams.update({"font.family": "serif", "font.size": 8, "axes.edgecolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID, "grid.linewidth": .5,
    "axes.axisbelow": True, "legend.frameon": False, "savefig.dpi": 600, "savefig.bbox": "tight", "figure.facecolor": "white"})

d = pd.read_csv(r"D:\diabetic project\REVISION_EXPERIMENTS\qpw_indicators.csv")
d = d[d.Scenario != "stationary"]; d = d[d.Client == d.DriftClient]
IND = [("Q", "Data quality $Q$"), ("P", "Performance $P$"), ("C", "Calibration $C$"), ("R", "Reliability $R$"), ("G", "Gain $G$")]
fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.7), sharey=True, gridspec_kw={"wspace": .08})
for ax, (sc, title) in zip(axs, [("label", "(a) Label drift (40% label flips)"), ("sensor", "(b) Sensor/data-quality drift")]):
    g = d[d.Scenario == sc].groupby("Round")
    for i, (c, lab) in enumerate(IND):
        s = g[c].mean(); ax.plot(s.index, s.values, color=SERIES[i], lw=1.3, label=lab)
    s = g["Weight"].mean(); ax.plot(s.index, s.values, color=INK, lw=1.6, ls="--", label="Aggregation weight $\\omega$")
    ax.axvline(25.5, color=INK2, ls=":", lw=.8); ax.set_xlabel("Communication round"); ax.set_ylim(0, 1)
    ax.set_title(title, loc="left", fontsize=8.2)
axs[0].set_ylabel("Indicator value / weight of drifted client")
axs[1].legend(ncol=3, fontsize=6.8, loc="lower center", bbox_to_anchor=(-.04, -.42))
fig.savefig(OUT + r"\fig_drift_indicators.png"); plt.close(fig)

# summary table: drifted-client indicators, rounds 21-25 vs 26-30, paired over seeds
from scipy.stats import wilcoxon
rows = []
for sc in ["label", "sensor"]:
    x = d[d.Scenario == sc]; a = x[x.Round.between(21, 25)].groupby("Seed").mean(numeric_only=True); b = x[x.Round.between(26, 30)].groupby("Seed").mean(numeric_only=True)
    for c in ["Q", "P", "C", "R", "G", "Weight"]:
        rows.append(dict(Scenario=sc, Indicator=c, Before=a[c].mean(), After=b[c].mean(), Delta=(b[c]-a[c]).mean(), SeedsDecreased=int(((b[c]-a[c]) < 0).sum()), Wilcoxon_p=wilcoxon(b[c], a[c]).pvalue))
t = pd.DataFrame(rows); t.to_csv(r"D:\diabetic project\FINAL_RESULTS\Phase3_Federated_QPW_Fed\csv\T24_P3_drifted_client_indicators.csv", index=False)
print(t.round(4).to_string())
