"""Draft 5 schematics: Fig. 1 (framework), Fig. 2 (CIR-CalBoost), Fig. 4 (QPW-Fed), redrawn from the author's layouts."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, FancyArrowPatch

FIG = r"D:\diabetic project\paper writing\FINAL_MANUSCRIPT_PACKAGE\figures"
plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "DejaVu Serif"], "mathtext.fontset": "stix",
                     "savefig.dpi": 600, "savefig.bbox": "tight", "savefig.pad_inches": 0.02, "figure.facecolor": "white"})

INK, INK2 = "#1a1a1a", "#404040"
GRAY, GRAY_H = "#f2f2f2", "#dedede"
BLUE, BLUE_L, BLUE_H = "#2e75b6", "#deebf7", "#bdd7ee"
ORNG, ORNG_L, ORNG_H = "#e46c0a", "#fde9d9", "#fbd4b4"
GRN, GRN_L, GRN_H = "#548235", "#ebf1de", "#d7e4bd"
PURP, PURP_L, PURP_H = "#7030a0", "#f6f1fa", "#e4dfec"


def new(w, h):
    fig, ax = plt.subplots(figsize=(w, h))
    ax.set_xlim(0, w); ax.set_ylim(0, h); ax.axis("off")
    return fig, ax


def rbox(ax, x, y, w, h, fc, ec, lw=0.8, ls="-", r=0.03, z=1):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad=0,rounding_size={r}", fc=fc, ec=ec, lw=lw, ls=ls, zorder=z))


def sbox(ax, x, y, w, h, fc, ec=INK2, lw=0.8, z=2):
    ax.add_patch(Rectangle((x, y), w, h, fc=fc, ec=ec, lw=lw, zorder=z))


def t(ax, x, y, s, fs=7, b=False, it=False, ha="center", va="center", c=INK, ls=1.25, z=6):
    ax.text(x, y, s, fontsize=fs, fontweight="bold" if b else "normal", style="italic" if it else "normal",
            ha=ha, va=va, color=c, linespacing=ls, zorder=z)


def arrow(ax, x1, y1, x2, y2, ls="-", lw=0.85, c=INK2):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=8, color=c, lw=lw, ls=ls,
                                 shrinkA=0, shrinkB=0, zorder=5))


def path(ax, pts, ls="-", lw=0.85, c=INK2, head=True):
    for (a, b), (c2, d) in zip(pts[:-2] if head else pts[:-1], pts[1:-1] if head else pts[1:]):
        ax.plot([a, c2], [b, d], color=c, lw=lw, ls=ls, zorder=5, solid_capstyle="butt")
    if head:
        arrow(ax, *pts[-2], *pts[-1], ls=ls, lw=lw, c=c)


def card(ax, x, y, w, h, title, lines, ec, fc, hc, tfs=7.6, fs=6.6, hh=0.26, note=None, ls=1.36):
    rbox(ax, x, y, w, h, fc, ec, z=2)
    rbox(ax, x, y + h - hh, w, hh, hc, ec, z=2.1)
    if note:
        t(ax, x + w / 2, y + h - 0.12, title, fs=tfs, b=True)
        t(ax, x + w / 2, y + h - hh + 0.085, note, fs=5.6, it=True, c=INK2)
    else:
        t(ax, x + w / 2, y + h - hh / 2, title, fs=tfs, b=True, ls=1.1)
    body = "\n".join(("     " + l[1:]) if l.startswith("~") else "\u2022  " + l for l in lines)
    t(ax, x + 0.09, y + h - hh - 0.07, body, fs=fs, ha="left", va="top", ls=ls)


def save(fig, name):
    for ext in ("pdf", "png"):
        fig.savefig(f"{FIG}\\{name}.{ext}")
    plt.close(fig)


# =============================================================== Fig. 1 framework
fig, ax = new(8.2, 3.6)
card(ax, 0.05, 2.45, 1.36, 1.05, "Pima Indians\nDiabetes Dataset", ["768 observations", "8 clinical predictors", "500 negative /", "~268 positive"],
     INK2, GRAY, GRAY_H, hh=0.42)
arrow(ax, 0.73, 2.45, 0.73, 2.04)
card(ax, 0.05, 0.62, 1.36, 1.42, "Data Preprocessing", ["Zeros recoded", "~as missing values", "Median imputation", "~(training data only)",
     "Standardization", "~(training data only)"], INK2, GRAY, GRAY_H)
path(ax, [(1.41, 1.60), (1.56, 1.60)], head=False)
path(ax, [(1.56, 0.98), (1.56, 2.78)], head=False)
arrow(ax, 1.56, 2.78, 1.70, 2.78); arrow(ax, 1.56, 0.98, 1.70, 0.98)

cx, cw = 1.70, 4.40
rbox(ax, cx, 1.95, cw, 1.60, ORNG_L, ORNG, lw=0.9, ls=(0, (4, 2)), z=0.5)
rbox(ax, cx + 0.07, 3.23, cw - 0.14, 0.26, ORNG_H, ORNG, lw=0.7, z=0.6)
t(ax, cx + cw / 2, 3.36, "Centralized Evaluation (Phases I and II)", fs=9, b=True)
card(ax, cx + 0.09, 2.03, 1.86, 1.12, "Phase I \u2014 Centralized Benchmark",
     ["Balanced Random Forest", "EasyEnsemble", "RUSBoost", "Class-weighted XGBoost", "SMOTEENN-XGBoost"],
     BLUE, BLUE_L, BLUE_H, tfs=6.7, fs=6.5, hh=0.36, note="5 seeds \u00d7 5-fold CV = 25 outer trials")
card(ax, cx + 2.35, 2.03, 1.96, 1.12, "Phase II \u2014 CIR-CalBoost",
     ["Clinical interaction features", "Interaction screening (top 5)", "XGBoost + RF + logistic regression",
      "Out-of-fold convex weighting", "Probability calibration", "Training-derived threshold"],
     ORNG, "#fff8f3", ORNG_H, tfs=6.9, fs=6.1, hh=0.36, note="same 25 outer partitions", ls=1.2)
arrow(ax, cx + 1.95, 2.50, cx + 2.35, 2.50, ls=(0, (3, 2)))
t(ax, cx + 2.15, 2.56, "shared\nCV folds", fs=5.3, it=True, c=INK2, va="bottom", ls=1.1)

fy, fh = 0.05, 1.82
rbox(ax, cx, fy, cw, fh, GRN_L, GRN, lw=0.9, ls=(0, (4, 2)), z=0.5)
rbox(ax, cx + 0.07, fy + fh - 0.32, cw - 0.14, 0.26, GRN_H, GRN, lw=0.7, z=0.6)
t(ax, cx + cw / 2, fy + fh - 0.19, "Federated Learning (Phase III)", fs=9, b=True)
rbox(ax, cx + 0.09, 0.86, 1.22, 0.62, "white", GRN, z=2)
t(ax, cx + 0.70, 1.33, "5 non-IID clients", fs=7.0, b=True)
t(ax, cx + 0.70, 1.06, "Dirichlet($\\alpha = 0.5$)\nMLP 8\u201332\u201316\u20131", fs=6.4)
rbox(ax, cx + 1.53, 0.86, 2.78, 0.62, "white", GRN, z=2)
t(ax, cx + 1.62, 1.37, "Federated aggregation methods", fs=7.0, b=True, ha="left")
t(ax, cx + 1.62, 1.07, "\u2022  FedAvg   \u2022  FedProx   \u2022  FedAdam   \u2022  Uniform\n"
  "\u2022  QPW-Fed (proposed: $N, Q, P, C, R, G$)\n\u2022  QPW-Fed-PC (prevalence correction)", fs=6.3, ha="left", ls=1.3)
arrow(ax, cx + 1.31, 1.17, cx + 1.53, 1.17)
sx, sw = [cx + 0.09, cx + 1.51, cx + 2.93], 1.38
scen = [("Stationary", "non-IID clients"), ("Label drift", "40% labels flipped\nlargest client, $r \\geq 26$"),
        ("Sensor drift", "60% missing + age noise\nlargest client, $r \\geq 26$")]
for x0, (a, d) in zip(sx, scen):
    rbox(ax, x0, 0.13, sw, 0.51, GRAY, GRN, z=2)
    t(ax, x0 + sw / 2, 0.53, a, fs=6.8, b=True)
    t(ax, x0 + sw / 2, 0.29, d, fs=5.9, ls=1.15)
mid = cx + 1.53 + 1.39
path(ax, [(mid, 0.86), (mid, 0.75)], head=False)
path(ax, [(sx[0] + sw / 2, 0.75), (sx[2] + sw / 2, 0.75)], head=False)
for x0 in sx:
    arrow(ax, x0 + sw / 2, 0.75, x0 + sw / 2, 0.64)
t(ax, mid + 0.06, 0.80, "evaluated under", fs=5.6, it=True, c=INK2, ha="left")

rx, rw = 6.28, 1.87
rbox(ax, rx, 2.00, rw, 1.55, BLUE_L, BLUE, z=1)
rbox(ax, rx, 3.28, rw, 0.27, BLUE_H, BLUE, z=1.1)
t(ax, rx + rw / 2, 3.415, "Predictive Evaluation", fs=7.8, b=True)
subs = [("Classification", "Accuracy, BAcc, F1, MCC,\nPrecision, Sensitivity, Specificity"), ("Discrimination", "ROC-AUC, PR-AUC"),
        ("Probability quality", "Brier, ECE, log loss,\nintercept, slope, O/E")]
for (a, d), y0, h0 in zip(subs, [2.80, 2.48, 2.06], [0.42, 0.28, 0.38]):
    rbox(ax, rx + 0.07, y0, rw - 0.14, h0, "white", BLUE, lw=0.7, z=2)
    t(ax, rx + rw / 2, y0 + h0 - 0.075, a, fs=6.5, b=True)
    t(ax, rx + rw / 2, y0 + (h0 - 0.13) / 2, d, fs=5.9, ls=1.15)
card(ax, rx, 0.93, rw, 0.95, "Statistical and Diagnostic Analysis",
     ["Corrected resampled $t$-test", "Wilcoxon + Holm, bootstrap CIs", "Client-weight evolution", "Effective prevalence",
      "Sensitivity analysis; ablation"], INK2, "white", GRAY_H, tfs=6.8, fs=5.9, hh=0.22, ls=1.3)
card(ax, rx, 0.05, rw, 0.78, "Research Findings", ["Predictive\u2013calibration trade-offs", "Adaptive client influence",
     "Drift detectability", "Prevalence-induced calibration shift"], PURP, PURP_L, PURP_H, tfs=7.0, fs=5.9, hh=0.22, ls=1.3)
arrow(ax, rx + rw / 2, 2.00, rx + rw / 2, 1.88)
arrow(ax, rx + rw / 2, 0.93, rx + rw / 2, 0.83)
arrow(ax, cx + cw, 2.75, rx, 2.75)
path(ax, [(cx + cw, 1.35), (cx + cw + 0.09, 1.35)], head=False)
path(ax, [(cx + cw + 0.09, 1.35), (cx + cw + 0.09, 2.27), (rx, 2.27)])
arrow(ax, cx + cw + 0.09, 1.35, rx, 1.35)
save(fig, "fig_framework_v6")


# =============================================================== Fig. 2 CIR-CalBoost
fig, ax = new(8.2, 3.62)
FT, FB = 7.6, 6.8
ax.add_patch(Rectangle((0.05, 0.92), 8.10, 2.64, fc="none", ec=ORNG, lw=1.0, ls=(0, (4, 2.5)), zorder=0.5))
t(ax, 0.16, 3.45, "Estimated on the training portion of each outer fold", fs=8, b=True, it=True, c=ORNG, ha="left")
y1, h1 = 2.40, 0.92
row = [(0.17, 1.12, "Clinical variables", "8 predictors"),
       (1.45, 1.17, "Preprocessing", "\u2022 Zeros as missing\n\u2022 Median imputation\n\u2022 Standardization"),
       (2.78, 1.62, "Interaction features $\\Phi(\\mathbf{x})$", "Glu$^2$, BMI$^2$,\nGlu \u00d7 BMI, Glu \u00d7 Age,\nBMI \u00d7 Age, Glu \u00d7 DPF"),
       (4.56, 1.36, "Interaction screening", "top 5 by $|\\mathrm{AUC}-0.5|$\n8 original + 5 interactions\n(13 predictors)")]
for i, (x0, w0, a, d) in enumerate(row):
    sbox(ax, x0, y1, w0, h1, ORNG_H)
    t(ax, x0 + w0 / 2, y1 + h1 - 0.17, a, fs=FT, b=True)
    t(ax, x0 + w0 / 2, y1 + (h1 - 0.30) / 2, d, fs=FB, ls=1.3)
    if i < 3:
        arrow(ax, x0 + w0, y1 + h1 / 2, row[i + 1][0], y1 + h1 / 2)
lx, lw_ = 6.20, 1.55
lys = [3.10, 2.76, 2.42]
for y0, a in zip(lys, ["XGBoost", "Random Forest", "Logistic Regression"]):
    sbox(ax, lx, y0, lw_, 0.27, BLUE_H)
    t(ax, lx + lw_ / 2, y0 + 0.135, a, fs=FT, b=True)
path(ax, [(5.92, y1 + h1 / 2), (6.06, y1 + h1 / 2)], head=False)
path(ax, [(6.06, lys[2] + 0.135), (6.06, lys[0] + 0.135)], head=False)
for y0 in lys:
    arrow(ax, 6.06, y0 + 0.135, lx, y0 + 0.135)
for y0 in lys:
    path(ax, [(lx + lw_, y0 + 0.135), (7.95, y0 + 0.135)], head=False)
path(ax, [(7.95, lys[0] + 0.135), (7.95, 2.27), (7.10, 2.27), (7.10, 2.10)])
y2, h2 = 1.06, 1.04
row2 = [(0.17, 2.75, "Threshold selection",
         "$\\tau \\in \\{0.30, 0.31, \\ldots, 0.60\\}$\n"
         "maximize  0.55 MCC + 0.25 BAcc + 0.10 F1\n+ 0.10 min(Sens, Spec)\n"
         "subject to  min(Sens, Spec) $\\geq$ 0.72 (if feasible)"),
        (3.12, 2.55, "Calibration selection", "None / Sigmoid / Isotonic\nminimize  0.45 Brier + 0.20 ECE + 0.35 log loss\n"
         "subject to  AUC decrease $\\leq$ 0.002"),
        (5.87, 2.20, "OOF convex ensemble weights", "$\\mathbf{w}^{*} \\in \\Delta$\ninner 5-fold cross-validation\nminimize OOF log loss")]
for i, (x0, w0, a, d) in enumerate(row2):
    sbox(ax, x0, y2, w0, h2, BLUE_L)
    t(ax, x0 + w0 / 2, y2 + h2 - 0.17, a, fs=FT, b=True)
    t(ax, x0 + w0 / 2, y2 + (h2 - 0.30) / 2, d, fs=FB, ls=1.35)
    if i > 0:
        arrow(ax, x0, y2 + h2 / 2, row2[i - 1][0] + row2[i - 1][1], y2 + h2 / 2)
arrow(ax, 1.67, y2, 1.67, 0.92)
path(ax, [(1.67, 0.92), (1.67, 0.42), (3.05, 0.42)])
sbox(ax, 3.05, 0.04, 2.35, 0.72, GRAY)
t(ax, 4.225, 0.59, "Outer held-out fold", fs=FT, b=True)
t(ax, 4.225, 0.27, "final evaluation only\n$\\hat{y} = \\mathbf{1}[\\,g^{*}(\\bar{p}) \\geq \\tau^{*}]$", fs=FB, ls=1.35)
t(ax, 1.76, 0.62, "fitted model ($\\mathbf{w}^{*}, g^{*}, \\tau^{*}$)", fs=6.2, it=True, c=INK2, ha="left")
t(ax, 7.0, 0.40, "outer test fold:\nnever used for fitting", fs=6.4, it=True, c=INK2, ls=1.2)
arrow(ax, 6.25, 0.40, 5.40, 0.40)
save(fig, "fig_cir_calboost_v2")


# =============================================================== Fig. 4 QPW-Fed
fig, ax = new(8.2, 3.45)
t(ax, 0.10, 3.36, "Local training / fixed local validation", fs=6.8, it=True, c=INK2, ha="left")
ctop = [3.22, 2.72, 2.22, 1.72, 1.22]
for i, y0 in enumerate(ctop):
    sbox(ax, 0.10, y0 - 0.40, 1.00, 0.40, GRN_H)
    t(ax, 0.60, y0 - 0.13, f"Client {i + 1}", fs=7.4, b=True)
    t(ax, 0.60, y0 - 0.30, "5 AdamW steps", fs=6.4)
ex, ew, ey, eh = 1.38, 1.00, 1.45, 1.50
for i, y0 in enumerate(ctop):
    arrow(ax, 1.10, y0 - 0.20, ex, ey + eh - 0.15 - i * (eh - 0.30) / 4)
sbox(ax, ex, ey, ew, eh, GRAY)
t(ax, ex + ew / 2, ey + eh - 0.30, "Client update\nand evidence", fs=7.4, b=True, ls=1.15)
t(ax, ex + ew / 2, ey + eh - 0.62, "$\\Delta\\theta_k$", fs=8)
t(ax, ex + ew / 2, ey + 0.38, "validation metrics\nbefore / after\nlocal training", fs=6.4, ls=1.25)
ind = [("N", "Sample contribution", "local sample share $n_k/n$"), ("Q", "Data quality", "completeness + class balance"),
       ("P", "Predictive performance", "MCC, BAcc, F1, ROC-AUC"), ("C", "Calibration quality", "1 \u2212 ECE"),
       ("R", "Update reliability", "cosine + norm agreement"), ("G", "Local improvement gain", "validation score after \u2212 before")]
ix, iw = 2.62, 1.68
iys = [3.30 - 0.34 - k * 0.40 for k in range(6)]
path(ax, [(ex + ew, ey + eh / 2), (2.50, ey + eh / 2)], head=False)
path(ax, [(2.50, iys[-1] + 0.17), (2.50, iys[0] + 0.17)], head=False)
for (L, a, d), y0 in zip(ind, iys):
    sbox(ax, ix, y0, iw, 0.34, BLUE_L)
    arrow(ax, 2.50, y0 + 0.17, ix, y0 + 0.17)
    t(ax, ix + 0.13, y0 + 0.17, L, fs=11, b=True)
    t(ax, ix + 0.28, y0 + 0.235, a, fs=7.0, b=True, ha="left")
    t(ax, ix + 0.28, y0 + 0.09, d, fs=6.1, ha="left")
    path(ax, [(ix + iw, y0 + 0.17), (4.43, y0 + 0.17)], head=False)
path(ax, [(4.43, iys[-1] + 0.17), (4.43, iys[0] + 0.17)], head=False)
sy, sh = 2.10, 1.20
steps = [(4.58, 1.06, "Weighted\ngeometric score", "$s_k = \\sum_{c} \\lambda_c \\ln c_k$\n$c \\in \\{N,Q,P,C,R,G\\}$"),
         (5.80, 1.10, "Temperature\nsoftmax", "$\\omega_k = \\dfrac{\\exp(s_k/T_s)}{\\sum_j \\exp(s_j/T_s)}$\n$T_s = 0.75$"),
         (7.05, 1.05, "Weight\nbounds", "$\\omega_k \\in [0.05, 0.40]$\niterative clipping\nand renormalization")]
arrow(ax, 4.43, sy + sh / 2, 4.58, sy + sh / 2)
for i, (x0, w0, a, d) in enumerate(steps):
    sbox(ax, x0, sy, w0, sh, ORNG_H)
    t(ax, x0 + w0 / 2, sy + sh - 0.24, a, fs=7.4, b=True, ls=1.12)
    t(ax, x0 + w0 / 2, sy + 0.40, d, fs=6.8, ls=1.5)
    if i < 2:
        arrow(ax, x0 + w0, sy + sh / 2, steps[i + 1][0], sy + sh / 2)
ax_, aw = 6.38, 1.72
sbox(ax, 4.58, 0.58, 1.45, 0.84, BLUE_L)
t(ax, 5.305, 1.27, "Update clipping", fs=7.4, b=True)
t(ax, 5.305, 0.88, "$\\|\\widehat{\\Delta\\theta}_k\\| \\leq 2m^{(t)}$\n$m^{(t)}$: median update norm", fs=6.6, ls=1.45)
sbox(ax, ax_, 0.80, aw, 0.66, ORNG_H)
t(ax, ax_ + aw / 2, 1.31, "Weighted aggregation", fs=7.4, b=True)
t(ax, ax_ + aw / 2, 1.00, "$\\sum_{k=1}^{K} \\omega_k \\widehat{\\Delta\\theta}_k$", fs=7.6)
arrow(ax, 7.575, sy, 7.575, 1.46)
t(ax, 7.50, 1.78, "bounded weights $\\omega_k$", fs=6.4, it=True, c=INK2, ha="right")
arrow(ax, 6.03, 1.00, ax_, 1.00)
t(ax, 6.205, 1.17, "clipped\nupdates", fs=5.5, it=True, c=INK2, va="bottom", ls=1.1)
path(ax, [(ex + ew / 2, ey), (ex + ew / 2, 0.72), (4.58, 0.72)])
t(ax, 2.30, 0.78, "raw model updates $\\Delta\\theta_k$", fs=6.4, it=True, c=INK2, ha="left", va="bottom")
sbox(ax, ax_, 0.04, aw, 0.56, GRAY)
t(ax, ax_ + aw / 2, 0.45, "Updated global model", fs=7.4, b=True)
t(ax, ax_ + aw / 2, 0.20, "$\\theta^{(t+1)} = \\theta^{(t)} + \\sum_{k} \\omega_k \\widehat{\\Delta\\theta}_k$", fs=7.0)
arrow(ax, ax_ + aw / 2, 0.80, ax_ + aw / 2, 0.60)
path(ax, [(ax_, 0.24), (0.60, 0.24), (0.60, ctop[-1] - 0.40)], ls=(0, (4, 2.5)))
t(ax, 3.4, 0.30, "broadcast $\\theta^{(t+1)}$ for the next communication round", fs=6.6, it=True, c=INK2, va="bottom")
t(ax, 3.4, 0.18, "repeat for 50 communication rounds", fs=6.6, it=True, c=INK2, va="top")
save(fig, "fig_qpw_fed_v2")
print("ok")
