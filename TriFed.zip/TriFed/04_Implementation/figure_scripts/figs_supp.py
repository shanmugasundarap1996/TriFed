"""Supplementary figures regenerated with all five federated methods (incl. Uniform)."""
import pickle, numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from sklearn.calibration import calibration_curve
EXP = r"D:\diabetic project\REVISION_EXPERIMENTS"
OUTS = [r"D:\diabetic project\paper writing\figures", r"D:\diabetic project\paper writing\FINAL_MANUSCRIPT_PACKAGE\figures"]
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#e87ba4", "#eda100"]; INK2, GRID = "#52514e", "#e4e3df"
plt.rcParams.update({"font.family": "serif", "font.size": 8, "axes.edgecolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID, "grid.linewidth": .5,
    "axes.axisbelow": True, "legend.frameon": False, "savefig.dpi": 600, "savefig.bbox": "tight", "figure.facecolor": "white"})
METH = [("FedAvg", "FedAvg"), ("FedProx", "FedProx"), ("FedAdam", "FedAdam"), ("UniformClip", "Uniform"), ("QPW", "QPW-Fed")]
def save(fig, name):
    for o in OUTS: fig.savefig(f"{o}\\{name}")
    plt.close(fig)

r = pd.read_csv(EXP + r"\all_rounds.csv"); r50 = r[(r.Kind == "main") & (r.Round == 50)]
seeds = sorted(r50.Seed.unique())
fig, ax = plt.subplots(figsize=(7.2, 2.7)); off = np.linspace(-.3, .3, len(METH))
for j, (m, lab) in enumerate(METH):
    g = r50[r50.Method == m].set_index("Seed").loc[seeds]
    ax.scatter(np.arange(len(seeds)) + off[j], g.MCC, s=16, color=SERIES[j], label=lab, zorder=3)
ax.set_xticks(range(len(seeds)), [str(s) for s in seeds], fontsize=6.8); ax.set_xlabel("Federated evaluation seed"); ax.set_ylabel("Round-50 MCC")
ax.grid(axis="x", visible=False); ax.legend(ncol=5, loc="upper left", bbox_to_anchor=(0, -.2), fontsize=7)
save(fig, "fig_perseed_mcc.png")

preds = pickle.load(open(EXP + r"\round50_predictions.pkl", "rb"))
def pooled(m):
    ys, ps = [], []
    for d in preds:
        if d["Kind"] == "main" and d["Method"] == m: ys += d["y"]; ps += d["p"]
    return np.array(ys), np.clip(np.array(ps), 1e-6, 1 - 1e-6)
fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.0), gridspec_kw={"wspace": .3})
axs[0].plot([0, 1], [0, 1], ls="--", color=INK2, lw=.8, label="Perfect calibration")
for j, (m, lab) in enumerate(METH):
    y, p = pooled(m); fr, mp = calibration_curve(y, p, n_bins=10, strategy="quantile")
    axs[0].plot(mp, fr, marker="o", ms=2.5, lw=1.1, color=SERIES[j], label=lab)
    axs[1].hist(p, bins=np.linspace(0, 1, 21), histtype="step", lw=1.1, color=SERIES[j], weights=np.ones(len(p)) / len(p))
axs[0].set(xlim=(0, 1), ylim=(0, 1), xlabel="Mean predicted probability", ylabel="Observed positive fraction")
axs[0].set_title("(a) Reliability (decile bins, pooled seeds)", loc="left", fontsize=8); axs[0].legend(fontsize=6.4, loc="upper left")
axs[1].set(xlabel="Predicted probability", ylabel="Share of test predictions"); axs[1].set_title("(b) Distribution of predicted risk", loc="left", fontsize=8)
save(fig, "fig_reliability_federated.png")
print("ok")
