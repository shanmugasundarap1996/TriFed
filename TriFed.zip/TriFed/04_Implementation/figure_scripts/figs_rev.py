import pickle, numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from sklearn.calibration import calibration_curve
from scipy.special import logit, expit
OUT = r"D:\diabetic project\paper writing\figures"; EXP = r"D:\diabetic project\REVISION_EXPERIMENTS"
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300"]; INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
plt.rcParams.update({"font.family": "serif", "font.size": 8, "axes.edgecolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID, "grid.linewidth": .5,
    "axes.axisbelow": True, "legend.frameon": False, "savefig.dpi": 600, "savefig.bbox": "tight", "figure.facecolor": "white"})
COL = {"FedAvg": SERIES[0], "UniformClip": SERIES[2], "QPW": SERIES[3]}; LAB = {"FedAvg": "FedAvg", "UniformClip": "Uniform", "QPW": "QPW-Fed"}

r = pd.read_csv(EXP + r"\all_rounds.csv"); w = pd.read_csv(EXP + r"\client_weights.csv")
# ---------------- drift figure: 2 scenarios x (AUC, MCC, drifted-client weight)
fig, axs = plt.subplots(2, 3, figsize=(7.2, 4.4), gridspec_kw={"hspace": .55, "wspace": .32})
for row, (sc, title) in enumerate([("drift_label", "Label noise"), ("drift_sensor", "Sensor failure")]):
    g = r[r.Kind == sc]; wd = w[(w.Scenario == sc)]; wd = wd[wd.Client == wd.DriftClient]
    for j, (met, lab) in enumerate([("ROC_AUC", "ROC-AUC"), ("MCC", "MCC")]):
        ax = axs[row, j]
        for m in ["FedAvg", "UniformClip", "QPW"]:
            s = g[g.Method == m].groupby("Round")[met].mean(); ax.plot(s.index, s.values, color=COL[m], lw=1.3, label=LAB[m])
        ax.axvline(25.5, color=INK2, ls=":", lw=.8); ax.set_xlabel("Round"); ax.set_ylabel(lab)
        ax.set_title(f"({'abcdef'[row*3+j]}) {title}: {lab}", loc="left", fontsize=7.8)
        ax.set_ylim(.78, .86) if met == "ROC_AUC" else ax.set_ylim(.25, .55)
    ax = axs[row, 2]
    for m in ["FedAvg", "UniformClip", "QPW"]:
        s = wd[wd.Method == m].groupby("Round").Weight.mean(); ax.plot(s.index, s.values, color=COL[m], lw=1.3, label=LAB[m])
    ax.axvline(25.5, color=INK2, ls=":", lw=.8); ax.set_ylim(0, .5); ax.set_xlabel("Round"); ax.set_ylabel("Weight of drifted client")
    ax.set_title(f"({'abcdef'[row*3+2]}) Drifted-client weight", loc="left", fontsize=7.8)
axs[0, 0].legend(fontsize=6.6, loc="lower right")
fig.savefig(OUT + r"\fig_drift.png"); plt.close(fig)

# ---------------- prior correction reliability
preds = pickle.load(open(EXP + r"\round50_predictions.pkl", "rb"))
f50 = r[(r.Round == 50) & (r.Kind == "main")].set_index(["Method", "Seed"])
def pooled(method, correct=False):
    ys, ps = [], []
    for d in preds:
        if d["Kind"] != "main" or d["Method"] != method: continue
        p = np.clip(np.array(d["p"]), 1e-6, 1-1e-6)
        if correct:
            e = f50.loc[(method, d["Seed"])]; p = expit(logit(p) - (logit(e.EffPrev) - logit(e.PoolPrev)))
        ys += d["y"]; ps += list(p)
    return np.array(ys), np.array(ps)
fig, ax = plt.subplots(figsize=(3.5, 3.0))
ax.plot([0, 1], [0, 1], ls="--", color=INK2, lw=.8, label="Perfect calibration")
for (m, c, lab, ls) in [("FedAvg", False, "FedAvg", "-"), ("QPW", False, "QPW-Fed (raw)", "-"), ("QPW", True, "QPW-Fed (prior-corrected)", "--")]:
    y, p = pooled(m, c); fr, mp = calibration_curve(y, p, n_bins=10, strategy="quantile")
    ax.plot(mp, fr, marker="o", ms=3, lw=1.3, ls=ls, color=COL[m] if not c else SERIES[5], label=lab)
ax.set_xlabel("Mean predicted probability"); ax.set_ylabel("Observed positive fraction"); ax.set_xlim(0, 1); ax.set_ylim(0, 1)
ax.legend(fontsize=6.6, loc="upper left")
fig.savefig(OUT + r"\fig_prior_correction.png"); plt.close(fig)

# ---------------- centralized figure from reproducible results
c = pd.read_csv(r"D:\diabetic project\REPRODUCIBLE_RESULTS\central_all_methods_25trials.csv").replace({"SMOTEENN_XGB": "SMOTEENN-XGB"})
cm = ["BalancedRF", "EasyEnsemble", "RUSBoost", "WeightedXGB", "SMOTEENN-XGB", "CIR-CalBoost"]
def grouped(ax, df, methods, metrics, labels, title, ylim=None):
    n = len(methods); width = .8/n; x = np.arange(len(metrics))
    for i, m in enumerate(methods):
        g = df[df.Method == m]
        ax.bar(x + (i-(n-1)/2)*width, [g[k].mean() for k in metrics], width*.9, yerr=[g[k].std() for k in metrics], color=SERIES[i], label=m,
               error_kw=dict(elinewidth=.6, capsize=1.5, ecolor=INK2), edgecolor="white", linewidth=.6)
    ax.set_xticks(x, labels); ax.set_title(title, loc="left", fontsize=8.5); ax.grid(axis="x", visible=False)
    if ylim: ax.set_ylim(*ylim)
fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.6), gridspec_kw={"width_ratios": [2, 1]})
grouped(axs[0], c, cm, ["Accuracy", "Balanced_Accuracy", "F1", "MCC", "ROC_AUC", "PR_AUC"], ["Acc", "BAcc", "F1", "MCC", "ROC-AUC", "PR-AUC"], "(a) Classification and discrimination (higher is better)", (.3, .92))
grouped(axs[1], c, cm, ["Brier", "ECE", "LogLoss"], ["Brier", "ECE", "Log loss"], "(b) Probability quality (lower is better)")
axs[0].legend(ncol=6, loc="upper left", bbox_to_anchor=(0, -.12), fontsize=7)
fig.savefig(OUT + r"\fig_centralized.png"); plt.close(fig)
print("ok")
