"""Re-run QPW-Fed (stationary, label drift, sensor drift) logging the six client indicators per round."""
import sys, os
sys.path.insert(0, r"C:\Users\shanmugam\AppData\Local\Temp\claude\d--diabetic-project\4ca46a47-cd1b-4e77-981a-a1a6bc021af1\scratchpad")
import numpy as np, pandas as pd
from multiprocessing import Pool
import fl_engine as E
from run_all import SEEDS, make_drift

OUT = r"D:\diabetic project\REVISION_EXPERIMENTS\qpw_indicators.csv"

def job(spec):
    kind, seed = spec
    log = []; orig = E.qweights
    def wrapped(meta, R, coef, T=.75, lo=.05, hi=.40):
        w = orig(meta, R, coef, T, lo, hi); rnd = len(log) // len(meta) + 1
        N = np.array([m['N'] for m in meta], float); N /= N.sum()
        for i, m in enumerate(meta):
            log.append(dict(Scenario=kind, Seed=seed, Round=rnd, Client=i+1, N=N[i], Q=m['Q'], P=m['P'], C=m['C'], R=float(R[i]), G=m['G'], Weight=float(w[i])))
        return w
    E.qweights = wrapped
    if kind == "stationary":
        rows, _, _ = E.run("QPW", seed)
        big = None
    else:
        cl, te = E.load_partition(seed); f, big = make_drift(kind, cl, seed)
        rows, _, _ = E.run("QPW", seed, clients=cl, test=te, drift=f)
    E.qweights = orig
    for r in log: r["DriftClient"] = (big + 1) if big is not None else int(np.argmax([0]))
    return log, rows[-1]['MCC'], rows[-1]['ROC_AUC']

if __name__ == "__main__":
    specs = [(k, s) for k in ["stationary", "label", "sensor"] for s in SEEDS]
    with Pool(processes=max(1, os.cpu_count() - 1)) as pool:
        res = pool.map(job, specs)
    df = pd.DataFrame([r for log, _, _ in res for r in log]); df.to_csv(OUT, index=False)
    for (k, s), (_, mcc, auc) in zip(specs, res): print(k, s, round(mcc, 4), round(auc, 4))
