"""Federated engine reproduced from notebook 05 (exact-source QPW-Fed) and notebook 03 cell 5 (FedAdam).
Adds: uniform-weight aggregation, prior-shift correction bookkeeping, and client-drift scenarios."""
import os, math, random, time
import numpy as np, pandas as pd, torch
from torch import nn
from sklearn.model_selection import train_test_split
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, precision_score, recall_score, f1_score,
                             matthews_corrcoef, roc_auc_score, average_precision_score, confusion_matrix,
                             brier_score_loss, log_loss)

FIN = r"D:\diabetic project\PHASE3_QPW_FED\PHASE3_FINAL_ALL_METHODS_QPWFED_V3"
FEATURES = ['Pregnancies','Glucose','BloodPressure','SkinThickness','Insulin','BMI','DiabetesPedigreeFunction','Age']
ZM = ['Glucose','BloodPressure','SkinThickness','Insulin','BMI']
N_CLIENTS, LOCAL_VAL_SIZE, ROUNDS, LOCAL_EPOCHS, LOCAL_LR = 5, .20, 50, 5, .001
THRESHOLD_GRID = np.arange(.25, .651, .025); EMA_BETA = .80; FEDPROX_MU = .01
FEDADAM = dict(lr=.01, b1=.90, b2=.99, tau=1e-3)
QPW_COEF = np.array([.15, .10, .25, .10, .20, .20]); CLIP_MULT = 2.0

torch.set_num_threads(1)

def seed_all(s): random.seed(s); np.random.seed(s); torch.manual_seed(s)

class DiabetesNet(nn.Module):
    def __init__(self):
        super().__init__(); self.network = nn.Sequential(nn.Linear(8,32), nn.ReLU(), nn.Dropout(.10), nn.Linear(32,16), nn.ReLU(), nn.Dropout(.05), nn.Linear(16,1))
    def forward(self, x): return self.network(x).squeeze(1)

def get_state(m): return {k: v.detach().cpu().clone() for k, v in m.state_dict().items()}
def init_model(s): seed_all(s); return get_state(DiabetesNet())

def ece(y, p, bins=10):
    y = np.asarray(y); p = np.asarray(p); ids = np.digitize(p, np.linspace(0,1,bins+1)[1:-1], right=True); out = 0.
    for b in range(bins):
        m = ids == b
        if m.any(): out += m.mean()*abs(y[m].mean()-p[m].mean())
    return float(out)

def fast_cls(y, pred):
    tp = int(((pred==1)&(y==1)).sum()); tn = int(((pred==0)&(y==0)).sum()); fp = int(((pred==1)&(y==0)).sum()); fn = int(((pred==0)&(y==1)).sum())
    sens = tp/(tp+fn) if tp+fn else 0.; spec = tn/(tn+fp) if tn+fp else 0.; prec = tp/(tp+fp) if tp+fp else 0.
    f1 = 2*prec*sens/(prec+sens) if prec+sens else 0.
    den = math.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)); mcc = (tp*tn-fp*fn)/den if den else 0.
    # sklearn balanced_accuracy with a single present class equals recall of that class
    if (y==1).sum()==0: bacc = spec
    elif (y==0).sum()==0: bacc = sens
    else: bacc = (sens+spec)/2
    return dict(MCC=mcc, Balanced_Accuracy=bacc, F1=f1, Recall_Sensitivity=sens, Specificity=spec)

def metrics(y, p, t):
    y = np.asarray(y, int); p = np.clip(np.asarray(p, float), 1e-7, 1-1e-7); pred = (p >= t).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0,1]).ravel(); spec = tn/(tn+fp) if tn+fp else 0
    two = len(np.unique(y)) == 2
    return {'Accuracy': accuracy_score(y,pred), 'Balanced_Accuracy': balanced_accuracy_score(y,pred),
            'Precision': precision_score(y,pred,zero_division=0), 'Recall_Sensitivity': recall_score(y,pred,zero_division=0),
            'Specificity': spec, 'F1': f1_score(y,pred,zero_division=0), 'MCC': matthews_corrcoef(y,pred),
            'ROC_AUC': roc_auc_score(y,p) if two else np.nan, 'PR_AUC': average_precision_score(y,p) if two else np.nan,
            'Brier': brier_score_loss(y,p), 'ECE': ece(y,p), 'LogLoss': log_loss(y,p,labels=[0,1])}

def predict(state, X):
    m = DiabetesNet(); m.load_state_dict(state); m.eval()
    with torch.no_grad(): return torch.sigmoid(m(torch.tensor(X, dtype=torch.float32))).numpy()

def fit_pre(df):
    X = df[FEATURES].copy(); X[ZM] = X[ZM].replace(0, np.nan); med = X.median().fillna(0); X = X.fillna(med)
    return med, X.mean(), X.std().replace(0, np.nan).fillna(1).clip(lower=1e-6)

def transform(df, med, mean, std):
    X = df[FEATURES].copy(); X[ZM] = X[ZM].replace(0, np.nan); X = (X.fillna(med)-mean)/std
    return X.astype('float32').values

def local_split(df, seed, cid):
    y = df.Outcome.astype(int); st = y if y.nunique()==2 and y.value_counts().min()>=2 else None
    a, b = train_test_split(df, test_size=LOCAL_VAL_SIZE, random_state=seed+1000*cid, stratify=st)
    return a.reset_index(drop=True), b.reset_index(drop=True)

def threshold(y, p):
    if len(np.unique(y)) < 2: return .5
    best = (-1e9, .5); p = np.clip(np.asarray(p, float), 1e-7, 1-1e-7); y = np.asarray(y, int)
    for t in THRESHOLD_GRID:
        m = fast_cls(y, (p >= t).astype(int))
        s = .5*m['MCC'] + .3*m['Balanced_Accuracy'] + .2*m['F1'] - (.1 if m['Recall_Sensitivity'] < .5 or m['Specificity'] < .5 else 0)
        if s > best[0]: best = (s, float(t))
    return best[1]

def val_metrics(y, p, t):
    y = np.asarray(y, int); p = np.clip(np.asarray(p, float), 1e-7, 1-1e-7)
    m = fast_cls(y, (p >= t).astype(int))
    m['ROC_AUC'] = roc_auc_score(y, p) if len(np.unique(y)) == 2 else np.nan
    m['ECE'] = ece(y, p); return m

def delta(local, glob): return {k: local[k]-glob[k] for k in glob}
def dnorm(d): return float(np.sqrt(sum(float(torch.sum(v.float()**2)) for v in d.values())))
def wdelta(ds, w): return {k: sum(float(a)*d[k] for a, d in zip(w, ds)) for k in ds[0]}
def cosine(a, b):
    n = na = nb = 0.
    for k in a:
        x = a[k].float().reshape(-1); y = b[k].float().reshape(-1)
        n += float(torch.dot(x,y)); na += float(torch.dot(x,x)); nb += float(torch.dot(y,y))
    return float(np.clip(n/(math.sqrt(na)*math.sqrt(nb)+1e-12), -1, 1))
def pos_weight(y):
    n = (y==0).sum(); p = (y==1).sum(); return 1. if n==0 or p==0 else float(np.clip(np.sqrt(n/p), 1, 3))

def train_client(glob, cdf, seed, cid, rnd, med, mean, std, prox=False):
    tr, va = local_split(cdf, seed, cid)
    Xtr = transform(tr, med, mean, std); Xv = transform(va, med, mean, std)
    ytr = tr.Outcome.astype(int).values; yv = va.Outcome.astype(int).values
    pb = predict(glob, Xv); mb = val_metrics(yv, pb, threshold(yv, pb))
    model = DiabetesNet(); model.load_state_dict(glob); model.train()
    opt = torch.optim.AdamW(model.parameters(), lr=LOCAL_LR, weight_decay=1e-4)
    crit = nn.BCEWithLogitsLoss(pos_weight=torch.tensor(pos_weight(ytr)))
    xt = torch.tensor(Xtr); yt = torch.tensor(ytr, dtype=torch.float32); torch.manual_seed(seed+10000*rnd+100*cid)
    for _ in range(LOCAL_EPOCHS):
        opt.zero_grad(); loss = crit(model(xt), yt)
        if prox: loss = loss + (FEDPROX_MU/2)*sum(torch.sum((p-glob[n])**2) for n, p in model.named_parameters())
        loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), 5); opt.step()
    loc = get_state(model); pa = predict(loc, Xv); ta = threshold(yv, pa); ma = val_metrics(yv, pa, ta)
    comp = 1 - va[ZM].eq(0).mean().mean(); bal = max(0, 1-abs(float(yv.mean())-.5)/.5)
    Q = float(np.clip(.6*comp+.4*bal, .05, 1)); auc = ma['ROC_AUC'] if np.isfinite(ma['ROC_AUC']) else .5
    P = float(np.clip(.45*((ma['MCC']+1)/2)+.25*ma['Balanced_Accuracy']+.15*ma['F1']+.15*auc, .05, 1))
    C = float(np.clip(1-ma['ECE'], .05, 1))
    before = .5*mb['MCC']+.3*mb['Balanced_Accuracy']+.2*mb['F1']; after = .5*ma['MCC']+.3*ma['Balanced_Accuracy']+.2*ma['F1']
    G = float(np.clip(.5+.5*(after-before), .05, 1))
    return delta(loc, glob), {'N': len(tr), 'Q': Q, 'P': P, 'C': C, 'G': G, 'Threshold': ta, 'Prev': float(ytr.mean())}

def reliability(ds, meta):
    ns = np.array([m['N'] for m in meta], float); ref = wdelta(ds, ns/ns.sum())
    norms = np.array([dnorm(d) for d in ds]); valid = norms[norms > 1e-12]; med = np.median(valid) if len(valid) else 1.
    return np.array([float(np.clip(.7*(cosine(d, ref)+1)/2 + .3*(.05 if n <= 1e-12 else np.exp(-abs(np.log(n/(med+1e-12)+1e-12)))), .05, 1)) for d, n in zip(ds, norms)])

def qweights(meta, R, coef, T=.75, lo=.05, hi=.40):
    N = np.array([m['N'] for m in meta], float); N /= N.sum()
    M = np.column_stack([N, [m['Q'] for m in meta], [m['P'] for m in meta], [m['C'] for m in meta], R, [m['G'] for m in meta]])
    s = (np.log(np.clip(M, .01, 1))*coef).sum(1); z = np.exp((s-s.max())/T); w = z/z.sum()
    for _ in range(30): w = np.clip(w, lo, hi); w /= w.sum()
    return w

def clip_ds(ds):
    norms = np.array([dnorm(d) for d in ds]); v = norms[norms > 1e-12]
    if not len(v): return ds
    mx = CLIP_MULT*np.median(v); return [{k: x*float(mx/(n+1e-12) if n > mx else 1) for k, x in d.items()} for d, n in zip(ds, norms)]

def load_partition(seed):
    sd = os.path.join(FIN, "partitions", f"seed_{seed}")
    return [pd.read_csv(os.path.join(sd, f"client_{k}.csv")) for k in range(1, 6)], pd.read_csv(os.path.join(sd, "global_test.csv"))

def run(method, seed, clients=None, test=None, drift=None, coef=QPW_COEF, T=.75, rounds=ROUNDS, log_weights=False):
    """method: FedAvg | FedProx | FedAdam | QPW | Uniform | UniformClip.  drift: callable(round, clients)->clients or None."""
    if clients is None: clients, test = load_partition(seed)
    base_clients = clients
    pp = [local_split(c, seed, k)[0] for k, c in enumerate(base_clients, 1)]
    med, mean, std = fit_pre(pd.concat(pp, ignore_index=True))
    glob = init_model(seed); X = transform(test, med, mean, std); y = test.Outcome.astype(int).values; Th = .5
    m1 = {k: torch.zeros_like(v) for k, v in glob.items()}; m2 = {k: torch.zeros_like(v) for k, v in glob.items()}
    rows, wrows = [], []
    for rnd in range(1, rounds+1):
        cur = drift(rnd, base_clients) if drift else base_clients
        ds, meta = [], []
        for cid, c in enumerate(cur, 1):
            d, m = train_client(glob, c, seed, cid, rnd, med, mean, std, prox=(method == "FedProx")); ds.append(d); meta.append(m)
        ns = np.array([m['N'] for m in meta], float); nw = ns/ns.sum()
        if method in ("FedAvg", "FedProx"):
            w = nw; ag = wdelta(ds, w); glob = {k: glob[k]+ag[k] for k in glob}
        elif method == "FedAdam":
            w = nw; ag = wdelta(ds, w)
            for k in glob:
                u = ag[k]; m1[k] = FEDADAM['b1']*m1[k]+(1-FEDADAM['b1'])*u; m2[k] = FEDADAM['b2']*m2[k]+(1-FEDADAM['b2'])*u*u
                mh = m1[k]/(1-FEDADAM['b1']**rnd); vh = m2[k]/(1-FEDADAM['b2']**rnd)
                glob[k] = glob[k] + FEDADAM['lr']*mh/(torch.sqrt(vh)+FEDADAM['tau'])
        elif method in ("Uniform", "UniformClip"):
            w = np.repeat(1/len(ds), len(ds)); ag = wdelta(clip_ds(ds) if method == "UniformClip" else ds, w); glob = {k: glob[k]+ag[k] for k in glob}
        elif method == "QPW":
            R = reliability(ds, meta); w = qweights(meta, R, coef, T); ag = wdelta(clip_ds(ds), w); glob = {k: glob[k]+ag[k] for k in glob}
        cur_t = float(np.clip(np.average([m['Threshold'] for m in meta], weights=w), .30, .60)); Th = EMA_BETA*Th+(1-EMA_BETA)*cur_t
        p = predict(glob, X); met = metrics(y, p, Th)
        eff_prev = float(np.sum(w*np.array([m['Prev'] for m in meta]))); pool_prev = float(np.sum(nw*np.array([m['Prev'] for m in meta])))
        rows.append({'Seed': seed, 'Method': method, 'Round': rnd, 'Threshold': Th, 'EffPrev': eff_prev, 'PoolPrev': pool_prev, **met})
        if log_weights:
            for i, m in enumerate(meta): wrows.append({'Seed': seed, 'Method': method, 'Round': rnd, 'Client': i+1, 'Weight': float(w[i]), 'N': m['N'], 'Prev': m['Prev']})
    return rows, wrows, (y, p, Th)
