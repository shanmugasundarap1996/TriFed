import sys, os, time, pickle
sys.path.insert(0, r"C:\Users\shanmugam\AppData\Local\Temp\claude\d--diabetic-project\4ca46a47-cd1b-4e77-981a-a1a6bc021af1\scratchpad")
import numpy as np, pandas as pd
from multiprocessing import Pool
from sklearn.model_selection import train_test_split
import fl_engine as E

OUT = r"D:\diabetic project\REVISION_EXPERIMENTS"
os.makedirs(OUT, exist_ok=True)
SEEDS = [104729,130363,155921,181081,205759,230003,254773,279001,303271,327673]
DEV_SEEDS = [11, 22, 33, 44, 55]
COLUMNS = E.FEATURES + ["Outcome"]

# ---------- development partitions (same procedure as notebook 05, new seeds) ----------
def make_clients(train, seed):
    rng = np.random.default_rng(seed); y = train.Outcome.values
    for _ in range(2000):
        ids = [[] for _ in range(5)]; ok = True
        for cls in [0, 1]:
            z = np.where(y == cls)[0].copy(); rng.shuffle(z); chunks = None
            for _ in range(1000):
                p = rng.dirichlet(np.repeat(.5, 5)); c = np.split(z, (np.cumsum(p)[:-1]*len(z)).astype(int))
                if min(map(len, c)) >= 2: chunks = c; break
            if chunks is None: ok = False; break
            for k, c in enumerate(chunks): ids[k] += c.tolist()
        if ok and min(map(len, ids)) >= 10: break
    return [train.iloc[np.asarray(x)].reset_index(drop=True) for x in ids]

def dev_partition(seed):
    df = pd.read_csv(r"D:\diabetic project\data\pima-indians-diabetes.csv", header=None, names=COLUMNS)
    tr, te = train_test_split(df, test_size=.2, stratify=df.Outcome, random_state=seed)
    return make_clients(tr.reset_index(drop=True), seed+17), te.reset_index(drop=True)

# ---------- drift scenarios: largest client corrupted from round 26 ----------
def make_drift(kind, clients, seed):
    big = int(np.argmax([len(c) for c in clients])); rng = np.random.default_rng(seed + 999)
    bad = clients[big].copy()
    if kind == "label":
        idx = rng.choice(len(bad), size=int(round(.4*len(bad))), replace=False)
        bad.loc[idx, "Outcome"] = 1 - bad.loc[idx, "Outcome"]
    elif kind == "sensor":
        idx = rng.choice(len(bad), size=int(round(.6*len(bad))), replace=False)
        for col in E.ZM: bad.loc[idx, col] = 0
        noise = rng.normal(0, 1, size=len(bad))
        bad["Age"] = (bad["Age"] + 8*noise).clip(lower=21).round()
    drifted = [c if i != big else bad for i, c in enumerate(clients)]
    def f(rnd, base): return drifted if rnd > 25 else base
    return f, big

def job(spec):
    kind, method, seed, extra = spec
    t0 = time.time()
    if kind == "main":
        rows, w, pred = E.run(method, seed, log_weights=True)
    elif kind.startswith("drift_"):
        cl, te = E.load_partition(seed); f, big = make_drift(kind.split("_")[1], cl, seed)
        rows, w, pred = E.run(method, seed, clients=cl, test=te, drift=f, log_weights=True)
        for r in rows: r["Scenario"] = kind; r["DriftClient"] = big + 1
        for r in w: r["Scenario"] = kind; r["DriftClient"] = big + 1
    elif kind == "dev":
        cl, te = dev_partition(seed); coef = np.array(extra["coef"]); T = extra["T"]
        rows, w, pred = E.run(method, seed, clients=cl, test=te, coef=coef, T=T)
        for r in rows: r["Config"] = extra["name"]
    rows = [dict(r, Kind=kind) for r in rows]
    return spec, rows, w, pred, time.time() - t0

if __name__ == "__main__":
    specs = []
    for m in ["FedAvg", "FedProx", "FedAdam", "QPW", "Uniform", "UniformClip"]:
        specs += [("main", m, s, None) for s in SEEDS]
    for kind in ["drift_label", "drift_sensor"]:
        for m in ["FedAvg", "UniformClip", "QPW"]:
            specs += [(kind, m, s, None) for s in SEEDS]
    full = [.15, .10, .25, .10, .20, .20]
    noG = list(np.array([.15, .10, .25, .10, .20, 0]) / .80)
    NP = list(np.array([.15, 0, .25, 0, 0, 0]) / .40)
    dev_cfgs = [dict(name=f"T={T}", coef=full, T=T) for T in [.25, .5, .75, 1.5, 3.0]] + \
               [dict(name="noG,T=0.75", coef=noG, T=.75), dict(name="N+P,T=0.75", coef=NP, T=.75)]
    for s in DEV_SEEDS:
        specs += [("dev", "QPW", s, c) for c in dev_cfgs]
        specs += [("dev", "FedAvg", s, dict(name="FedAvg", coef=full, T=.75)), ("dev", "UniformClip", s, dict(name="UniformClip", coef=full, T=.75))]
    print("jobs:", len(specs), flush=True)
    t0 = time.time(); results = []
    with Pool(processes=max(1, os.cpu_count() - 1)) as pool:
        for i, res in enumerate(pool.imap_unordered(job, specs), 1):
            results.append(res)
            if i % 20 == 0: print(f"{i}/{len(specs)} done, {time.time()-t0:.0f}s", flush=True)
    rows = [r for _, rr, _, _, _ in results for r in rr]
    wts = [r for _, _, ww, _, _ in results for r in ww]
    pd.DataFrame(rows).to_csv(os.path.join(OUT, "all_rounds.csv"), index=False)
    pd.DataFrame(wts).to_csv(os.path.join(OUT, "client_weights.csv"), index=False)
    preds = [dict(Kind=sp[0], Method=sp[1], Seed=sp[2], Config=(sp[3] or {}).get("name"), y=list(map(int, pr[0])), p=list(map(float, pr[1])), Th=float(pr[2])) for sp, _, _, pr, _ in results]
    pickle.dump(preds, open(os.path.join(OUT, "round50_predictions.pkl"), "wb"))
    rt = pd.DataFrame([dict(Kind=sp[0], Method=sp[1], Seed=sp[2], Seconds=t) for sp, _, _, _, t in results])
    rt.to_csv(os.path.join(OUT, "runtime.csv"), index=False)
    print("total wall-clock:", round(time.time()-t0), "s; mean per run:", round(rt.Seconds.mean(), 1), "s; cpus:", os.cpu_count(), flush=True)
