# TriFed-Diabetes — final results: all three phases, existing vs proposed

This folder holds every result used in the manuscript (`paper writing/draft5_*`).

| Folder | Contents |
|---|---|
| `Phase1_Existing_Centralized/` | Five existing imbalance-aware methods |
| `Phase2_Proposed_CIR_CalBoost/` | Proposed centralized model vs the existing methods |
| `Phase3_Federated_QPW_Fed/` | Existing FL methods vs proposed QPW-Fed: stationary, drift, calibration, sensitivity, ablation |
| `ALL_RESULTS_TABLES.xlsx` | All 23 tables in one workbook (one sheet each) |

Each phase folder contains `csv/` (raw and summary data), `tables/` (formatted Markdown tables with captions) and `figures/` (600-dpi PNG).

**Dataset:** Pima Indians Diabetes, 768 adult women, 268 positive (34.9%), file `D:\diabetic project\pima-indians-diabetes.csv`.
**Reading the tables:** values are mean ± SD; **bold** = best; ↓ = lower is better.
**Metrics:** BAcc = balanced accuracy; MCC = Matthews correlation coefficient. Brier, ECE and log loss measure probability quality (calibration).

---

## Phase I — Existing centralized methods

**What was done.** Five established imbalance-aware methods were evaluated: BalancedRF, EasyEnsemble, RUSBoost, class-weighted XGBoost and SMOTEENN-XGB.
- Protocol: 5 seeds × stratified 5-fold CV, giving 25 test folds per method.
- Imputation, scaling and resampling are fitted on the training fold only.
- Probabilities are thresholded at 0.5.

**Main results** (Table P1-1, `fig_P1_existing_baselines.png`):
- **BalancedRF is the strongest existing method overall.** Accuracy 0.759, MCC 0.496, ROC-AUC 0.835, and the best calibration (ECE 0.091).
- **SMOTEENN-XGB catches the most diabetes cases** (sensitivity 0.809) but has the worst probabilities (ECE 0.187, Brier 0.206).
- **Resampling methods distort probabilities.** EasyEnsemble and SMOTEENN-XGB change the class balance seen in training, which pushes predicted risks away from reality.
- **RUSBoost is clearly the weakest** (MCC 0.430).
- **No existing method wins everything** (Table P1-3), which is why Phase II compares against the best existing method *per metric*.

| File | What it is |
|---|---|
| `csv/P1_baselines_per_trial_25.csv` | Every fold, every metric |
| `tables/T01…` | Mean ± SD of 12 metrics |
| `tables/T02…` | Per-seed means |
| `tables/T03…` | Best existing method per metric |

---

## Phase II — Proposed CIR-CalBoost vs existing methods

**What was done.** CIR-CalBoost runs inside each training fold. It:
1. adds 6 clinical interaction features and keeps the 8 originals plus the 5 most informative interactions;
2. trains XGBoost, a random forest and logistic regression;
3. combines them with convex weights learned out-of-fold;
4. selects a calibration mapping (none, sigmoid or isotonic);
5. selects a balanced decision threshold.

It was compared with the five Phase-I methods on the same 25 folds.

**Main results** (Tables P2-1 to P2-5, `fig_centralized.png`, `fig_P2_reliability_centralized.png`):

| Metric | Best existing | CIR-CalBoost | Better? |
|---|---|---|---|
| Accuracy | 0.759 (BalancedRF) | 0.755 | no (essentially equal) |
| Balanced accuracy | 0.755 (EasyEnsemble) | **0.762** | yes |
| F1 | 0.683 (SMOTEENN-XGB) | **0.691** | yes |
| MCC | 0.496 (BalancedRF) | **0.506** | yes |
| ROC-AUC | 0.835 (BalancedRF) | **0.840** | yes |
| PR-AUC | 0.717 (WeightedXGB) | **0.724** | yes |
| Brier ↓ | 0.162 (BalancedRF) | **0.157** | yes |
| ECE ↓ | 0.091 (BalancedRF) | **0.084** | yes |
| Log loss ↓ | 0.490 (BalancedRF) | **0.474** | yes |

**Interpretation.** CIR-CalBoost is best on 8 of 9 metrics. Its *statistically reliable* advantage is probability quality (corrected resampled t-test, Table P2-3/P2-4):
- **Log loss** is significantly lower than every existing method (Holm p ≤ 0.037).
- **Brier score** is significantly lower than the three resampling methods (p ≤ 0.004), and lower in 5 of 5 seeds against all methods.
- **Discrimination gains are consistent but not significant.** BAcc, MCC and AUC differences fail the test; ROC-AUC is still higher in 5 of 5 seeds against every method.

The fair one-line summary: **CIR-CalBoost matches the best existing methods at ranking patients and gives more trustworthy risk probabilities.** It reaches SMOTEENN-XGB-level sensitivity (0.784 vs 0.809) with far better calibration (ECE 0.084 vs 0.187).

**Inside the model** (Table P2-5):
- The random forest dominates the ensemble (weight 0.67), followed by logistic regression (0.27); XGBoost gets 0.06.
- Calibration chose "none" in 16 folds and sigmoid in 9.
- The mean threshold is 0.39, so the default 0.5 is rarely best.

**Provenance** (Table P2-6). The original centralized code could not be found, so it was rebuilt from the recovered specification: notebooks `code/R1_…` and `code/R2_…`. The rebuilt results are within about 0.01 of the original frozen run. **The paper reports the rebuilt (reproducible) numbers.**

---

## Phase III — Federated learning: existing methods vs proposed QPW-Fed

**Setup** (all methods identical except the aggregation rule):
- 5 clients per seed, created with Dirichlet(0.5), giving very unequal sizes (14–330) and positive rates (2%–98%) (`fig_client_heterogeneity.png`, Table P3-13);
- the same small neural network for every method;
- 50 rounds, with Round 50 fixed in advance as the endpoint;
- 10 seeds.

**Methods compared:**
- Existing: FedAvg, FedProx and FedAdam.
- **Uniform** (equal weights): a baseline added in the revision.
- **QPW-Fed** (proposed): re-weights clients every round from sample size, data quality, performance, calibration, update reliability and local improvement.
- **QPW-Fed-PC** (proposed): QPW-Fed plus the prevalence correction.

**Reproducibility.** Notebook `code/R3_…` reproduces the original federated results **exactly** (difference 0.000 in MCC and AUC for all 40 original runs).

### III-a. Stationary federation (Table P3-1, `fig_federated.png`, `fig_convergence.png`, `fig_perseed_mcc.png`)

| Method | Accuracy | BAcc | MCC | ROC-AUC | PR-AUC | Brier ↓ | ECE ↓ |
|---|---|---|---|---|---|---|---|
| FedAvg | **0.771** | 0.754 | 0.505 | 0.844 | 0.721 | 0.160 | 0.100 |
| FedProx | **0.771** | 0.754 | **0.506** | 0.844 | 0.720 | 0.160 | 0.100 |
| FedAdam | 0.754 | 0.730 | 0.471 | 0.834 | 0.701 | 0.172 | 0.110 |
| Uniform | 0.744 | 0.758 | 0.499 | 0.848 | 0.732 | 0.161 | 0.102 |
| **QPW-Fed** | 0.754 | **0.761** | 0.505 | **0.848** | **0.733** | **0.157** | **0.088** |

**Interpretation:**
- **Primary endpoint (MCC): no significant difference** between QPW-Fed and FedAvg or FedProx (Holm p = 1.00), nor FedAdam (Holm p = 0.32) (Table P3-2).
- **QPW-Fed trades about 1.7 points of accuracy for sensitivity.** It catches more diabetes cases (0.785 vs 0.696, higher in 10 of 10 seeds) with lower specificity (Table P3-3).
- **Against Uniform, discrimination is the same** (AUC p = 0.77), but QPW-Fed has better probabilities (Brier p = 0.037, log loss p = 0.010).

So the six indicators add **probability quality**. The ranking improvement comes from simply **not letting the largest client dominate**.

### III-b. Client weights and the prior-shift effect (Tables P3-4, P3-12; `fig_client_weights.png`, `fig_qpw_diagnostics.png`, `fig_reliability_federated.png`)

**How the weights differ.**
- FedAvg gives the largest client 0.435 of the influence and the smallest 0.055.
- QPW-Fed keeps weights between about 0.15 and 0.25 (entropy 0.989, close to uniform's 1.0).
- The local-gain indicator G hardly varies between clients.

**Key insight: re-weighting clients also re-weights the diabetes prevalence the model learns.**
- Effective prevalence is 0.349 under FedAvg, 0.392 under QPW-Fed and 0.414 under Uniform.
- The model therefore **over-predicts risk.** QPW-Fed's mean predicted risk is 0.400 against a true rate of 0.351 (calibration intercept −0.29, O/E 0.88).
- Across seeds, the prevalence increase tracks the over-prediction almost perfectly (Spearman ρ = 0.94).

### III-c. Proposed prevalence correction, QPW-Fed-PC (Tables P3-4, P3-5; `fig_prior_correction.png`)

**Method.** Shift each prediction back by the known prevalence difference. Ranking (AUC) and yes/no decisions are unchanged; only the probabilities move.

**Results:**
- The intercept goes from −0.287 to −0.107, and O/E from 0.88 to 0.96.
- Against FedAvg, QPW-Fed-PC has:
  - a smaller calibration error in the large (p = 0.037);
  - lower ECE (9 of 10 seeds, p = 0.027);
  - lower Brier score (p = 0.049).
- **On 5 independent development seeds**, the correction moved the intercept from −0.256 to −0.058, the same as FedAvg (−0.059). There it restores calibration but does not beat FedAvg.

### III-d. Client drift: the evolving-systems test (Tables P3-6 to P3-8, `fig_drift.png`)

From round 26, the **largest client was corrupted**, in two scenarios:
- **label noise:** 40% of its diagnoses flipped;
- **sensor failure:** 60% of its records lost five measurements.

| Scenario | Method | ROC-AUC (Round 50) | Change vs no drift | MCC |
|---|---|---|---|---|
| Label noise | FedAvg | 0.827 | **−0.017** | 0.439 |
| Label noise | Uniform | 0.841 | −0.006 | 0.473 |
| Label noise | **QPW-Fed** | 0.840 | −0.008 | **0.482** |
| Sensor failure | FedAvg | 0.842 | −0.002 | 0.474 |
| Sensor failure | Uniform | 0.846 | −0.001 | **0.494** |
| Sensor failure | **QPW-Fed** | **0.847** | −0.001 | 0.489 |

**Interpretation:**
- **Under label noise, QPW-Fed is much more robust than FedAvg.** ROC-AUC is higher in 9 of 10 seeds (p = 0.004), PR-AUC in 10 of 10 (p = 0.002), and Brier is better in 9 of 10 (p = 0.004). FedAvg keeps giving the corrupted client 43.5% of the influence.
- **Uniform is equally robust**, so the protection comes from **bounded, even weights**, not from detecting the drift.
- **What the weights detected** (Table P3-8):
  - *Sensor failure:* QPW-Fed cut the drifted client's weight from 0.248 to 0.229 immediately, because its data-quality indicator saw the missing values.
  - *Label noise:* the weight did not change, because a corrupted client judges itself on its own corrupted data.

This is an important finding for evolving systems: **self-reported client evidence cannot detect concept drift in the same client.** Detecting it needs external (cross-client or server-side) evidence.

### III-e. Sensitivity on independent development seeds (Table P3-9)

- **The temperature hardly changes MCC** (0.49–0.52).
- **Higher temperatures drift towards uniform behaviour**: higher effective prevalence and worse calibration.
- **A low temperature (0.25) behaves like FedAvg**, with similar AUC and calibration.
- **Removing G, or keeping only N+P, does not help.**
- **QPW-Fed's small advantages over FedAvg did not replicate on these seeds.** This is reported openly in the paper.

### III-f. Ablation (Tables P3-10, P3-11, `fig_ablation.png`)

The ablation reproduced the full model exactly.
- **N+P (A1)** gives the best MCC, BAcc and F1.
- **The full rule (A4)** gives the best ROC-AUC and PR-AUC.
- **No full-versus-reduced difference is significant** (Holm p = 1.00).

### III-g. Cost (Table P3-14)

About 15 s per 50-round run on one CPU core (AMD Ryzen 5 5625U). QPW-Fed adds under 1% communication: five numbers per client per round versus 833 model parameters.

---

## Bottom line

| Phase | Proposed method | What it achieves | What it does not achieve |
|---|---|---|---|
| II | CIR-CalBoost | Best on 8/9 metrics; significantly better probabilities (log loss, Brier) | Not more accurate; discrimination gains not significant |
| III | QPW-Fed | Same MCC as FedAvg; better BAcc, AUC and probabilities; far more robust than FedAvg when a large client drifts | Not better than simple uniform weighting at ranking; cannot detect label drift; over-predicts risk |
| III | QPW-Fed-PC | Fixes the over-prediction; better calibrated than FedAvg on the evaluation seeds | Calibration advantage over FedAvg not replicated on development seeds |

## How to reproduce

| Notebook | Reproduces |
|---|---|
| `code/R1_Phase1_Baselines_Reproducible.ipynb` | Phase I |
| `code/R2_CIR_CalBoost_Reproducible.ipynb` | Phase II |
| `code/R3_Federated_All_Methods_and_Revision.ipynb` | Phase III (all federated, drift, sensitivity and correction experiments) |

Raw run outputs are in `REPRODUCIBLE_RESULTS/` and `REVISION_EXPERIMENTS/`. The original frozen runs are kept unchanged in `FROZEN_FINAL_CIR_CALBOOST_V2/` and `PHASE3_QPW_FED/`.
